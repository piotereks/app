// ── Content Script ──────────────────────────────────────────────────────────
// DOM manipulation, UI rendering, and local interactions
// Syncs with background worker via chrome.runtime.sendMessage

const CONFIG = {
    maxCommentLen: 50,
    dbKey: 'global_listing_db',
};

// Local state
let db = {};
let suppressRender = false;

// ──────────────────────────────────────────────────────────────────────────────
// UTILITIES
// ──────────────────────────────────────────────────────────────────────────────

function getSite() {
    const host = location.hostname;
    if (host.endsWith('.olx.pl') || host === 'olx.pl') return 'olx';
    if (host.endsWith('.otomoto.pl') || host === 'otomoto.pl') return 'otomoto';
    if (host.includes('otomoto')) return 'otomoto';
    if (host.includes('olx')) return 'olx';
    if (document.title?.toLowerCase().includes('otomoto')) return 'otomoto';
    return 'olx';
}

function extractSiteFromUrl(url) {
    if (url.includes('.olx.pl') || url.includes('//olx.pl')) return 'olx';
    if (url.includes('.otomoto.pl') || url.includes('//otomoto.pl')) return 'otomoto';
    if (url.includes('olx')) return 'olx';
    return 'otomoto';
}

function extractId(url) {
    const clean = url.split('?')[0].split('#')[0];
    let m = clean.match(/(?:^|[-_\/])id([A-Za-z0-9]+?)(?:\.html)?$/i);
    if (m) return m[1];
    m = clean.match(/\/oferta\/([A-Za-z0-9]+)(?:\.html)?$/i);
    if (m) return m[1];
    m = clean.match(/\/d\/oferta\/([A-Za-z0-9]+)(?:\.html)?$/i);
    if (m) return m[1];
    return null;
}

function getCurrentId() {
    return extractId(location.href);
}

function makeKeyFromUrl(url) {
    const id = extractId(url);
    if (!id) return null;
    return extractSiteFromUrl(url) + ':' + id;
}

function makeKey(id) {
    return getSite() + ':' + id;
}

function now() {
    return new Date().toISOString();
}

function formatDate(iso) {
    if (!iso) return '';
    const d = new Date(iso);
    return [d.getDate(), d.getMonth() + 1, d.getFullYear()]
        .map(n => String(n).padStart(2, '0'))
        .join('.')
        + ', '
        + [d.getHours(), d.getMinutes(), d.getSeconds()]
            .map(n => String(n).padStart(2, '0'))
            .join(':');
}

// ──────────────────────────────────────────────────────────────────────────────
// MESSAGING (to background worker)
// ──────────────────────────────────────────────────────────────────────────────

function sendMessage(action, payload = {}) {
    return new Promise((resolve, reject) => {
        chrome.runtime.sendMessage({ action, payload }, (response) => {
            if (chrome.runtime.lastError) {
                reject(new Error(chrome.runtime.lastError.message));
            } else if (response?.error) {
                reject(new Error(response.error));
            } else {
                resolve(response);
            }
        });
    });
}

async function loadDB() {
    const response = await sendMessage('getDB');
    db = response.db || {};
    return db;
}

async function saveDB() {
    await sendMessage('saveDB', { db });
}

// ──────────────────────────────────────────────────────────────────────────────
// WRITE HELPERS
// ──────────────────────────────────────────────────────────────────────────────

async function writeEntry(key, patch) {
    if (!db[key]) db[key] = {};
    Object.assign(db[key], patch, { updatedAt: now() });
    await saveDB();
}

function normalizeComment(value) {
    return String(value || '')
        .replace(/\r?\n/g, ' ')
        .replace(/[\t ]+/g, ' ')
        .slice(0, CONFIG.maxCommentLen);
}

async function setComment(id, value) {
    const normalized = normalizeComment(value);
    const key = makeKey(id);
    const current = (db[key] || {}).comment || '';
    if (current === normalized) return;
    await writeEntry(key, { id, site: getSite(), comment: normalized });
    updateVisibleComment(key, normalized);
}

async function setCommentByKey(id, dbKey, value) {
    const normalized = normalizeComment(value);
    const current = (db[dbKey] || {}).comment || '';
    if (current === normalized) return;
    const site = dbKey.split(':')[0];
    await writeEntry(dbKey, { id, site, comment: normalized });
    updateVisibleComment(dbKey, normalized);
}

// ──────────────────────────────────────────────────────────────────────────────
// ACTIONS
// ──────────────────────────────────────────────────────────────────────────────

async function updateViewed() {
    const id = getCurrentId();
    if (!id) return;
    const key = makeKey(id);
    await writeEntry(key, { id, site: getSite(), viewedAt: now() });
}

async function ban(id) {
    await writeEntry(makeKey(id), {
        id,
        site: getSite(),
        banned: true,
        status: '',
        bannedAt: now(),
    });
    render();
}

async function unban(id) {
    await writeEntry(makeKey(id), { banned: false, status: 'D' });
    render();
}

async function banByKey(id, dbKey) {
    const site = dbKey.split(':')[0];
    await writeEntry(dbKey, {
        id,
        site,
        banned: true,
        status: '',
        bannedAt: now(),
    });
    render();
}

async function unbanByKey(id, dbKey) {
    await writeEntry(dbKey, { banned: false, status: 'D' });
    render();
}

async function setRating(id) {
    const key = makeKey(id);
    const cur = (db[key] || {}).rating;
    await writeEntry(key, {
        id,
        site: getSite(),
        rating: cycleRating(cur),
        ratedAt: now(),
    });
    render();
}

async function setRatingByKey(id, dbKey) {
    const cur = (db[dbKey] || {}).rating;
    const site = dbKey.split(':')[0];
    await writeEntry(dbKey, {
        id,
        site,
        rating: cycleRating(cur),
        ratedAt: now(),
    });
    render();
}

function cycleRating(v) {
    if (!v) return 3;
    if (v === 3) return 2;
    if (v === 2) return 1;
    return null;
}

function getRatingStyle(v) {
    if (v === 3) return { color: '#ff2b2b', label: '★' };
    if (v === 2) return { color: '#ffd400', label: '★' };
    if (v === 1) return { color: '#1e90ff', label: '★' };
    return { color: 'rgba(255,255,255,0.7)', label: '☆' };
}

// ──────────────────────────────────────────────────────────────────────────────
// SELECTORS
// ──────────────────────────────────────────────────────────────────────────────

const HEART_SEL = {
    olx: [
        '[data-testid="favourites-button"]',
        '[data-testid="favourite-button"]',
        '[data-testid="observed-offer"]',
        '[data-testid*="favourit"]',
        '[data-testid*="observed"]',
        '[aria-label*="avoryt"]',
        '[aria-label*="Obserwuj"]',
        '[aria-label*="obserwuj"]',
        'button[class*="FavouriteButton"]',
        'button[class*="ObservedButton"]',
        'button[class*="favourite"]',
        'button[class*="favorite"]',
        '[data-cy*="favourit"]',
    ].join(','),
    otomoto: [
        '[data-testid*="favourite"]',
        '[data-testid*="observed"]',
        '[data-testid*="wishlist"]',
        '[aria-label*="ulub"]',
        '[aria-label*="obserw"]',
        '[aria-label*="watch"]',
        '[data-cy*="favourite"]',
        '[data-cy*="favorite"]',
        'button[class*="Favourite"]',
        'button[class*="Observed"]',
        'button[class*="favourite"]',
        'button[class*="favorite"]',
    ].join(','),
};

function getHeartSelector(site) {
    return site === 'otomoto' ? HEART_SEL.otomoto : HEART_SEL.olx;
}

function getCard(a, site) {
    const selectors =
        site === 'otomoto'
            ? [
                  '[data-testid="listing-ad"]',
                  '[data-testid="ad-card"]',
                  '[data-testid*="listing"]',
                  '[data-testid*="AdCard"]',
                  '[class*="listing"]',
                  '[class*="offer-item"]',
                  '[class*="offer-card"]',
                  '[class*="ad-card"]',
                  '[class*="offer"]',
                  '[class*="card"]',
                  'article[data-id]',
                  'article',
                  'section',
                  'li',
              ]
            : [
                  '[data-cy="l-card"]',
                  'article[data-id]',
                  '[data-testid="listing-ad"]',
                  '[data-testid="ad-card"]',
                  '[data-testid*="listing"]',
                  '[data-testid*="AdCard"]',
                  '[class*="ooa-"][class*="card"]',
                  '[class*="offer-item"]',
                  '[class*="card"]',
                  '[data-testid*="card"]',
              ];

    for (const sel of selectors) {
        const card = a.closest(sel) || a.querySelector(sel);
        if (card) return card;
    }
    return null;
}

function isListingLink(a, site) {
    const href = (a.getAttribute('href') || '').toLowerCase();
    if (!href || href.startsWith('#') || href.startsWith('javascript:') || href.startsWith('mailto:'))
        return false;

    const id = extractId(href);
    const looksOlx =
        href.includes('/oferta/') ||
        href.includes('/d/oferta/') ||
        href.includes('olx.pl') ||
        href.includes('/oferta');
    const looksOtomoto =
        href.includes('/oferta/') ||
        href.includes('/ogloszenie/') ||
        href.includes('/advert/') ||
        href.includes('otomoto.pl') ||
        href.includes('otomoto') ||
        href.includes('/osobowe/');

    if (site === 'otomoto') {
        return !!id ? looksOtomoto || looksOlx : looksOtomoto;
    }
    return !!id ? looksOlx || looksOtomoto : looksOlx;
}

// ──────────────────────────────────────────────────────────────────────────────
// FADE
// ──────────────────────────────────────────────────────────────────────────────

function applyFade(card, isBanned) {
    if (!card) return;
    card.style.opacity = isBanned ? '0.35' : '';
    card.style.filter = isBanned ? 'grayscale(1)' : '';
}

// ──────────────────────────────────────────────────────────────────────────────
// OVERLAY LAYER
// ──────────────────────────────────────────────────────────────────────────────

function getLayer() {
    let layer = document.getElementById('olx-script-layer');
    if (!layer) {
        layer = document.createElement('div');
        layer.id = 'olx-script-layer';
        layer.style.cssText =
            'position:fixed;top:0;left:0;width:0;height:0;z-index:999998;pointer-events:none;';
        document.body.appendChild(layer);
    }
    return layer;
}

function buildChip(id, data, dbKey) {
    const chip = document.createElement('div');
    chip.className = 'script-chip';
    chip.setAttribute('data-id', id);
    chip.setAttribute('data-db-key', dbKey);
    chip.style.cssText = [
        'position:fixed',
        'display:flex',
        'gap:4px',
        'align-items:center',
        'background:rgba(0,0,0,0.78)',
        'border-radius:6px',
        'padding:3px 7px',
        'pointer-events:auto',
        'cursor:default',
        'z-index:999999',
        'font-family:sans-serif',
    ].join(';');

    if (data.viewedAt) {
        const eye = document.createElement('span');
        eye.textContent = '👁';
        eye.style.cssText = 'font-size:12px;line-height:1;opacity:0.9;pointer-events:none;';
        chip.appendChild(eye);
    }

    const r = getRatingStyle(data.rating);
    const star = document.createElement('span');
    star.textContent = r.label;
    star.style.cssText = 'font-size:14px;color:' + r.color + ';line-height:1;cursor:pointer;user-select:none;';
    star.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        setRatingByKey(id, dbKey);
    });
    chip.appendChild(star);

    const commentBox = document.createElement('div');
    commentBox.style.cssText = [
        'display:flex',
        'flex-direction:column',
        'align-items:flex-start',
        'gap:2px',
        'max-width:90px',
    ].join(';');

    const commentLabel = document.createElement('span');
    commentLabel.className = 'comment-label';
    commentLabel.textContent = data.comment || 'comment';
    commentLabel.style.cssText = [
        'font-size:9px',
        'font-weight:bold',
        'color:#fff7b2',
        'background:rgba(255,247,178,0.16)',
        'border:1px solid rgba(255,247,178,0.45)',
        'border-radius:999px',
        'padding:1px 5px',
        'max-width:80px',
        'white-space:nowrap',
        'overflow:hidden',
        'text-overflow:ellipsis',
        'line-height:1.2',
    ].join(';');
    commentBox.appendChild(commentLabel);

    const commentInput = document.createElement('input');
    commentInput.className = 'comment-input';
    commentInput.type = 'text';
    commentInput.id = 'comment-input-' + String(dbKey).replace(/[^a-z0-9]+/gi, '-');
    commentInput.name = commentInput.id;
    commentInput.setAttribute('autocomplete', 'off');
    commentInput.setAttribute('aria-label', 'Comment');
    commentInput.maxLength = CONFIG.maxCommentLen;
    commentInput.placeholder = 'comment';
    commentInput.value = data.comment || '';
    commentInput.title = 'Short comment (max ' + CONFIG.maxCommentLen + ' chars)';
    commentInput.style.cssText = [
        'width:90px',
        'padding:2px 4px',
        'border-radius:4px',
        'border:1px solid rgba(255,255,255,0.25)',
        'background:rgba(255,255,255,0.12)',
        'color:white',
        'font-size:9px',
        'outline:none',
        'box-sizing:border-box',
    ].join(';');

    commentInput.addEventListener('mousedown', (e) => {
        e.stopPropagation();
        suppressRender = true;
    });
    commentInput.addEventListener('pointerdown', (e) => {
        e.stopPropagation();
        suppressRender = true;
    });
    commentInput.addEventListener('focus', () => {
        suppressRender = true;
    });
    commentInput.addEventListener('keydown', () => {
        suppressRender = true;
    });
    commentInput.addEventListener('blur', () => {
        suppressRender = false;
        updateVisibleComment(dbKey, commentInput.value);
    });
    commentInput.addEventListener('input', (e) => {
        const value = normalizeComment(e.target.value);
        e.target.value = value;
        commentLabel.textContent = value || 'comment';
        setCommentByKey(id, dbKey, value);
    });

    commentBox.appendChild(commentInput);
    chip.appendChild(commentBox);

    const btn = document.createElement('button');
    btn.textContent = data.banned ? 'BANNED' : 'BAN';
    btn.style.cssText = [
        'background:' + (data.banned ? '#cc0000' : '#222'),
        'color:white',
        'border:none',
        'font-size:9px',
        'font-weight:bold',
        'padding:2px 5px',
        'border-radius:3px',
        'cursor:pointer',
        'line-height:1.4',
    ].join(';');
    btn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        data.banned ? unbanByKey(id, dbKey) : banByKey(id, dbKey);
    });
    chip.appendChild(btn);

    return chip;
}

function updateVisibleComment(dbKey, value) {
    const comment = value || '';
    document.querySelectorAll('.script-chip').forEach((chip) => {
        if (chip.getAttribute('data-db-key') !== dbKey) return;
        const label = chip.querySelector('.comment-label');
        if (label) label.textContent = comment || 'comment';
        const input = chip.querySelector('.comment-input');
        if (input && document.activeElement !== input) input.value = comment;
    });
}

function positionChip(chip, card, site) {
    const heart = card.querySelector(getHeartSelector(site));
    const cardRect = card.getBoundingClientRect();
    let top, left;

    if (heart) {
        const hr = heart.getBoundingClientRect();
        top = hr.top + (hr.height - 24) / 2;
        left = hr.left - chip.offsetWidth - 6;
        if (chip.offsetWidth === 0) left = hr.left - 80;
    } else {
        top = cardRect.top + 8;
        left = site === 'otomoto' ? cardRect.left + 8 : cardRect.right - 90;
    }

    chip.style.top = Math.round(top) + 'px';
    chip.style.left = Math.round(left) + 'px';
}

function renderList() {
    const layer = getLayer();
    const pageId = getCurrentId();
    const site = getSite();

    layer.querySelectorAll('.script-chip').forEach((c) => c.remove());

    const visited = new Set();

    document.querySelectorAll('a[href]').forEach((a) => {
        const id = extractId(a.href);
        if (!id || id === pageId) return;
        if (!isListingLink(a, site)) return;
        if (
            a.closest('header') ||
            a.closest('nav') ||
            a.closest('[role="dialog"]') ||
            a.closest('#notification-hub-dropdown')
        )
            return;

        const card = getCard(a, site);
        if (!card || visited.has(card)) return;
        visited.add(card);

        const dbKey = makeKeyFromUrl(a.href);
        if (!dbKey) return;

        const data = db[dbKey] || {};
        applyFade(card, data.banned);

        const chip = buildChip(id, data, dbKey);
        chip.setAttribute('data-href', a.href);
        layer.appendChild(chip);
        requestAnimationFrame(() => positionChip(chip, card, site));
    });
}

function repositionAll() {
    const layer = getLayer();
    const site = getSite();

    layer.querySelectorAll('.script-chip').forEach((chip) => {
        const id = chip.getAttribute('data-id');
        const href = chip.getAttribute('data-href');
        if (!id) return;

        let a = href
            ? document.querySelector('a[href="' + href + '"]') ||
              document.querySelector('a[href*="-ID' + id + '"]')
            : document.querySelector('a[href*="-ID' + id + '"]');

        if (!a) return;
        const card = getCard(a, site);
        if (card) positionChip(chip, card, site);
    });
}

// ──────────────────────────────────────────────────────────────────────────────
// DETAIL PAGE UI
// ──────────────────────────────────────────────────────────────────────────────

function cleanupUI() {
    document.getElementById('ban-ui')?.remove();
    document.getElementById('ban-bar')?.remove();
}

function renderBanner(id, data) {
    if (!data.banned) return;

    const bar = document.createElement('div');
    bar.id = 'ban-bar';
    bar.style.cssText = [
        'position:fixed',
        'bottom:0',
        'left:0',
        'width:100%',
        'z-index:2147483647',
        'background:linear-gradient(90deg,#b00000,#ff2b2b)',
        'color:white',
        'display:flex',
        'align-items:center',
        'justify-content:center',
        'gap:14px',
        'padding:10px 20px',
        'box-sizing:border-box',
        'font-family:sans-serif',
        'font-size:14px',
        'font-weight:bold',
    ].join(';');

    const label = document.createElement('span');
    const commentText = data.comment ? ' | comment: ' + data.comment : '';
    label.textContent = '🚫 BANNED | ID: ' + id + ' | since: ' + formatDate(data.bannedAt) + commentText;

    const ubtn = document.createElement('button');
    ubtn.textContent = 'UNBAN';
    ubtn.style.cssText =
        'background:white;color:#b00000;border:none;padding:5px 12px;border-radius:5px;cursor:pointer;font-weight:bold;font-size:13px;';
    ubtn.addEventListener('click', () => unban(id));

    bar.appendChild(label);
    bar.appendChild(ubtn);
    document.body.appendChild(bar);
}

function renderPage() {
    const id = getCurrentId();
    if (!id) return;

    updateViewed();

    const data = db[makeKey(id)] || {};

    const ui = document.createElement('div');
    ui.id = 'ban-ui';
    ui.style.cssText = [
        'position:fixed',
        'bottom:' + (data.banned ? '76px' : '20px'),
        'right:20px',
        'z-index:2147483647',
        'background:rgba(0,0,0,0.92)',
        'padding:10px 14px',
        'border-radius:10px',
        'display:flex',
        'gap:10px',
        'align-items:center',
        'font-family:sans-serif',
    ].join(';');

    const eye = document.createElement('span');
    eye.textContent = '👁';
    eye.style.cssText = 'font-size:18px;opacity:0.9;';
    ui.appendChild(eye);

    const r = getRatingStyle(data.rating);
    const star = document.createElement('span');
    star.textContent = r.label;
    star.style.cssText = 'font-size:22px;color:' + r.color + ';cursor:pointer;user-select:none;';
    star.addEventListener('click', () => setRating(id));
    ui.appendChild(star);

    const commentBox = document.createElement('div');
    commentBox.style.cssText = [
        'display:flex',
        'flex-direction:column',
        'align-items:flex-start',
        'gap:2px',
        'min-width:120px',
        'max-width:140px',
    ].join(';');

    const commentLabel = document.createElement('span');
    commentLabel.className = 'comment-label';
    commentLabel.textContent = data.comment || 'comment';
    commentLabel.style.cssText = [
        'font-size:11px',
        'color:rgba(255,255,255,0.95)',
        'white-space:nowrap',
        'overflow:hidden',
        'text-overflow:ellipsis',
        'max-width:100%',
    ].join(';');
    commentBox.appendChild(commentLabel);

    const commentInput = document.createElement('input');
    commentInput.className = 'comment-input';
    commentInput.type = 'text';
    commentInput.id = 'comment-input-' + String(id).replace(/[^a-z0-9]+/gi, '-');
    commentInput.name = commentInput.id;
    commentInput.setAttribute('autocomplete', 'off');
    commentInput.setAttribute('aria-label', 'Comment');
    commentInput.maxLength = CONFIG.maxCommentLen;
    commentInput.placeholder = 'comment';
    commentInput.value = data.comment || '';
    commentInput.title = 'Short comment (max ' + CONFIG.maxCommentLen + ' chars)';
    commentInput.style.cssText = [
        'width:100%',
        'padding:6px 8px',
        'border-radius:6px',
        'border:1px solid rgba(255,255,255,0.2)',
        'background:rgba(255,255,255,0.12)',
        'color:white',
        'font-size:12px',
        'outline:none',
        'box-sizing:border-box',
    ].join(';');

    commentInput.addEventListener('mousedown', (e) => {
        e.stopPropagation();
        suppressRender = true;
    });
    commentInput.addEventListener('pointerdown', (e) => {
        e.stopPropagation();
        suppressRender = true;
    });
    commentInput.addEventListener('focus', () => {
        suppressRender = true;
    });
    commentInput.addEventListener('keydown', () => {
        suppressRender = true;
    });
    commentInput.addEventListener('blur', () => {
        suppressRender = false;
        updateVisibleComment(makeKey(id), commentInput.value);
    });
    commentInput.addEventListener('input', (e) => {
        const value = normalizeComment(e.target.value);
        e.target.value = value;
        commentLabel.textContent = value || 'comment';
        setComment(id, value);
    });

    commentBox.appendChild(commentInput);
    ui.appendChild(commentBox);

    const btn = document.createElement('button');
    btn.textContent = data.banned ? 'UNBAN' : 'BAN';
    btn.style.cssText = [
        'background:' + (data.banned ? 'red' : '#222'),
        'color:white',
        'border:none',
        'padding:6px 12px',
        'border-radius:6px',
        'cursor:pointer',
        'font-weight:bold',
        'font-size:13px',
    ].join(';');
    btn.addEventListener('click', () => (data.banned ? unban(id) : ban(id)));
    ui.appendChild(btn);

    document.body.appendChild(ui);
    renderBanner(id, data);
}

// ──────────────────────────────────────────────────────────────────────────────
// MAIN RENDER
// ──────────────────────────────────────────────────────────────────────────────

function render() {
    if (suppressRender) return;
    cleanupUI();
    renderList();
    renderPage();
}

// ──────────────────────────────────────────────────────────────────────────────
// OBSERVERS
// ──────────────────────────────────────────────────────────────────────────────

function isRelevantMutation(mutations) {
    const selectors = [
        'a[href]',
        '[data-cy="l-card"]',
        'article[data-id]',
        'article',
        'section',
        'li',
        '[data-testid="listing-ad"]',
        '[data-testid="ad-card"]',
        '[data-testid*="listing"]',
        '[data-testid*="AdCard"]',
        '[class*="ooa-"][class*="card"]',
        '[class*="offer-item"]',
        '[class*="offer-card"]',
        '[class*="offer"]',
        '[class*="listing"]',
        '[class*="card"]',
    ].join(',');

    return mutations.some((mutation) => {
        const nodes = [...mutation.addedNodes, ...mutation.removedNodes];
        return nodes.some((node) => {
            if (!node || node.nodeType !== 1) return false;
            const el = node;
            if (el.matches?.(selectors)) return true;
            if (el.querySelector?.(selectors)) return true;
            return false;
        });
    });
}

function startObserver() {
    let scheduled = false;
    new MutationObserver((mutations) => {
        if (!isRelevantMutation(mutations)) return;
        if (scheduled) return;
        scheduled = true;
        requestAnimationFrame(() => {
            renderList();
            scheduled = false;
        });
    }).observe(document.body, { childList: true, subtree: true });
}

function startPositionWatch() {
    let rafId = null;
    const onMove = () => {
        if (rafId) return;
        rafId = requestAnimationFrame(() => {
            repositionAll();
            rafId = null;
        });
    };
    window.addEventListener('scroll', onMove, { passive: true });
    window.addEventListener('resize', onMove, { passive: true });
}

function startNavWatch() {
    let last = location.href;
    const onNav = () => {
        if (location.href !== last) {
            last = location.href;
            render();
        }
    };
    setInterval(onNav, 200);
    window.addEventListener('popstate', () => requestAnimationFrame(onNav));
    window.addEventListener('hashchange', () => requestAnimationFrame(onNav));
}

function ensureSearchOrder() {
    const host = location.hostname;
    const isOlx = host.endsWith('.olx.pl') || host === 'olx.pl';
    const isOtomoto = host.endsWith('.otomoto.pl') || host === 'otomoto.pl';
    if (!isOlx && !isOtomoto) return;

    const u = new URL(location.href);
    if (u.searchParams.has('search[order]')) return;

    const value = isOlx ? 'created_at:desc' : 'created_at_first:desc';
    u.searchParams.set('search[order]', value);
    location.href = u.toString();
}

// ──────────────────────────────────────────────────────────────────────────────
// INIT
// ──────────────────────────────────────────────────────────────────────────────

async function init() {
    try {
        await loadDB();
        ensureSearchOrder();
        render();
        startObserver();
        startPositionWatch();
        startNavWatch();
        console.log('[Content] Initialized');
    } catch (e) {
        console.error('[Content] Init error:', e);
    }
}

init();
