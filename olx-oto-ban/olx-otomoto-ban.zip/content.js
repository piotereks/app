// ── DEPRECATED ───────────────────────────────────────────────────────────────
// content.js has been split into three files for proper OLX/Otomoto separation:
//
//   shared.js       — common engine (messaging, DB, UI, observers, init)
//   olx-site.js     — OLX-specific selectors, positioning, search order
//   otomoto-site.js — Otomoto-specific selectors, positioning, search order
//
// The manifest.json now uses separate content_script entries so each site
// loads only its own code. Edit those files instead.
// ──────────────────────────────────────────────────────────────────────────────

console.warn('[OLX Ban] content.js is deprecated. Use shared.js + olx-site.js or otomoto-site.js.');