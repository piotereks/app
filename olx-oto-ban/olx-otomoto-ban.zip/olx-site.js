// ── OLX Site Module ──────────────────────────────────────────────────────────
// Sets OLX-specific config on __BAN, then inits shared engine.
// Runs only on https://*.olx.pl/* (see manifest.json).
// ──────────────────────────────────────────────────────────────────────────────

(function() {

console.log('[OLX Ban] OLX site module loaded');

window.__BAN = window.__BAN || {};

__BAN.SITE         = 'olx';
__BAN.CHIP_POS     = 'right';
__BAN.SEARCH_ORDER = 'created_at:desc';

__BAN.PRICE_SEL = '[data-testid="ad-price"]';

__BAN.HEART_SEL = [
    '[data-testid="favourites-button"]',
    '[data-testid="favourite-button"]',
    '[data-testid="observed-offer"]',
    '[data-testid*="favourit"]',
    '[data-testid*="observed"]',
    '[aria-label*="avoryt"]',
    '[aria-label*="Obserwuj"]',
    '[aria-label*="obserwuj"]',
    'button[class*="FavouriteButton"]',
    'button[class*="ObservedButton"]',
    'button[class*="favourite"]',
    'button[class*="favorite"]',
    '[data-cy*="favourit"]',
].join(',');

__BAN.CARD_SELS = [
    '[data-cy="l-card"]',
    'article[data-id]',
    '[data-testid="listing-ad"]',
    '[data-testid="ad-card"]',
    '[data-testid*="listing"]',
    '[data-testid*="AdCard"]',
    '[class*="ooa-"][class*="card"]',
    '[class*="offer-item"]',
    '[class*="card"]',
    '[data-testid*="card"]',
];

__BAN.OBSERVER_SELS = [
    '[data-cy="l-card"]',
    '[class*="offer-item"]',
    '[class*="ooa-"][class*="card"]',
];

__BAN.LISTING_PATTERNS = [
    'olx.pl',
    'olx',
    '/oferta/',
];

// ── Inline controls (inserted before heart button in each card) ──────────────

function buildInlineControls(id, data, dbKey) {
    var controls = document.createElement('div');
    controls.className = 'olx-ban-inline-controls';
    controls.setAttribute('data-db-key', dbKey);
    controls.setAttribute('data-id', id);
    controls.style.cssText = [
        'display:inline-flex',
        'align-items:center',
        'gap:2px',
        'margin-right:4px',
        'vertical-align:middle',
    ].join(';');

    if (data.viewedAt) {
        var eye = document.createElement('span');
        eye.className = 'olx-ban-inline-eye';
        eye.textContent = '\uD83D\uDC41';
        eye.style.cssText = 'font-size:10px;line-height:1;opacity:0.9;pointer-events:none;';
        controls.appendChild(eye);
    }

    var r = __BAN.getRatingStyle(data.rating);
    var star = document.createElement('span');
    star.className = 'olx-ban-inline-star';
    star.textContent = r.label;
    star.style.cssText = [
        'font-size:12px',
        'color:' + r.color,
        'line-height:1',
        'cursor:pointer',
        'user-select:none',
    ].join(';');
    star.addEventListener('click', function(e) {
        e.preventDefault();
        e.stopPropagation();
        __BAN.setRatingByKey(id, dbKey);
    });
    controls.appendChild(star);

    var comment = document.createElement('span');
    comment.className = 'olx-ban-inline-comment';
    comment.textContent = data.comment || 'comment';
    comment.title = data.comment || '';
    comment.style.cssText = [
        'font-size:8px',
        'font-weight:' + (data.comment ? 'bold' : 'normal'),
        'color:#fff7b2',
        'background:rgba(255,247,178,0.16)',
        'border:1px solid rgba(255,247,178,0.45)',
        'border-radius:999px',
        'padding:' + (data.comment ? '1px 4px' : '0'),
        'max-width:40px',
        'white-space:nowrap',
        'overflow:hidden',
        'text-overflow:ellipsis',
        'line-height:1.2',
        'cursor:pointer',
    ].join(';');
    comment.addEventListener('click', function(e) {
        e.stopPropagation();
        var input = controls.querySelector('.olx-ban-inline-comment-input');
        if (input) {
            input.focus();
            input.select();
        }
    });
    controls.appendChild(comment);

    var input = document.createElement('input');
    input.className = 'olx-ban-inline-comment-input';
    input.type = 'text';
    input.setAttribute('autocomplete', 'off');
    input.maxLength = 50;
    input.placeholder = '';
    input.value = data.comment || '';
    input.style.cssText = [
        'display:none',
        'width:60px',
        'padding:1px 3px',
        'border-radius:3px',
        'border:1px solid rgba(255,255,255,0.25)',
        'background:rgba(255,255,255,0.12)',
        'color:white',
        'font-size:8px',
        'outline:none',
        'box-sizing:border-box',
    ].join(';');
    input.addEventListener('blur', function() {
        input.style.display = 'none';
        comment.style.display = '';
        var val = __BAN.normalizeComment(input.value);
        comment.textContent = val || 'comment';
        comment.style.fontWeight = val ? 'bold' : 'normal';
        comment.style.padding = val ? '1px 4px' : '0';
        __BAN.updateVisibleComment(dbKey, val);
    });
    input.addEventListener('input', function(e) {
        var val = __BAN.normalizeComment(e.target.value);
        e.target.value = val;
        __BAN.setCommentByKey(id, dbKey, val);
    });
    controls.appendChild(input);

    var btn = document.createElement('button');
    btn.className = 'olx-ban-inline-btn';
    btn.textContent = data.banned ? 'BANNED' : 'BAN';
    btn.style.cssText = [
        'background:' + (data.banned ? '#cc0000' : '#222'),
        'color:white',
        'border:none',
        'font-size:8px',
        'font-weight:bold',
        'padding:1px 4px',
        'border-radius:2px',
        'cursor:pointer',
        'line-height:1.4',
    ].join(';');
    btn.addEventListener('click', function(e) {
        e.preventDefault();
        e.stopPropagation();
        if (data.banned) {
            __BAN.unbanByKey(id, dbKey);
        } else {
            __BAN.banByKey(id, dbKey);
        }
    });
    controls.appendChild(btn);

    return controls;
}

__BAN.renderInlineControls = function(db) {
    var pageId = __BAN.extractId ? __BAN.extractId(location.href) : null;

    document.querySelectorAll('.olx-ban-inline-controls').forEach(function(el) {
        el.remove();
    });

    var seenKeys = {};

    document.querySelectorAll('a[href]').forEach(function(a) {
        var href = (a.getAttribute('href') || '').toLowerCase();
        if (!href || href.startsWith('#') || href.startsWith('javascript:') || href.startsWith('mailto:')) return;
        if (a.closest('header') || a.closest('nav') || a.closest('[role="dialog"]') || a.closest('#notification-hub-dropdown')) return;

        var id = __BAN.extractId(a.href);
        if (!id || id === pageId) return;

        var card = null;
        for (var i = 0; i < __BAN.CARD_SELS.length; i++) {
            card = a.closest(__BAN.CARD_SELS[i]) || a.querySelector(__BAN.CARD_SELS[i]);
            if (card) break;
        }
        if (!card) return;

        var dbKey = 'olx:' + id;
        if (seenKeys[dbKey]) return;
        seenKeys[dbKey] = true;

        var collapseBar = document.querySelector('.olx-ban-collapse-bar[data-db-key="' + dbKey + '"]');
        if (collapseBar) return;

        var heart = card.querySelector(__BAN.HEART_SEL);
        if (!heart) return;

        var data = (db && db[dbKey]) || {};
        var controls = buildInlineControls(id, data, dbKey);
        heart.parentNode.insertBefore(controls, heart);
    });
};

__BAN.updateInlineControls = function(dbKey) {
    var controls = document.querySelector('.olx-ban-inline-controls[data-db-key="' + dbKey + '"]');
    if (!controls) return;

    var db = typeof __BAN.getDB === 'function' ? __BAN.getDB() : {};
    var data = (db && db[dbKey]) || {};
    var id = controls.getAttribute('data-id');

    var eye = controls.querySelector('.olx-ban-inline-eye');
    if (data.viewedAt) {
        if (!eye) {
            var newEye = document.createElement('span');
            newEye.className = 'olx-ban-inline-eye';
            newEye.textContent = '\uD83D\uDC41';
            newEye.style.cssText = 'font-size:10px;line-height:1;opacity:0.9;pointer-events:none;';
            controls.insertBefore(newEye, controls.firstChild);
        }
    } else if (eye) {
        eye.remove();
    }

    var star = controls.querySelector('.olx-ban-inline-star');
    if (star) {
        var r = __BAN.getRatingStyle(data.rating);
        star.textContent = r.label;
        star.style.color = r.color;
    }

    var comment = controls.querySelector('.olx-ban-inline-comment');
    if (comment) {
        comment.textContent = data.comment || 'comment';
        comment.style.fontWeight = data.comment ? 'bold' : 'normal';
        comment.style.padding = data.comment ? '1px 4px' : '0';
    }

    var input = controls.querySelector('.olx-ban-inline-comment-input');
    if (input && document.activeElement !== input) {
        input.value = data.comment || '';
    }

    var btn = controls.querySelector('.olx-ban-inline-btn');
    if (btn) {
        btn.textContent = data.banned ? 'BANNED' : 'BAN';
        btn.style.background = data.banned ? '#cc0000' : '#222';
    }
};

__BAN.init();

})();
