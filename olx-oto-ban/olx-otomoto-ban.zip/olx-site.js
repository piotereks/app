// ── OLX Site Module ──────────────────────────────────────────────────────────
// Sets OLX-specific config on __BAN, then inits shared engine.
// Runs only on https://*.olx.pl/* (see manifest.json).
// ──────────────────────────────────────────────────────────────────────────────

(function() {

console.log('[OLX Ban] OLX site module loaded');

window.__BAN = window.__BAN || {};

__BAN.SITE         = 'olx';
__BAN.CHIP_POS     = 'right';
__BAN.SEARCH_ORDER = 'created_at:desc';

__BAN.PRICE_SEL = '[data-testid="ad-price"]';

__BAN.HEART_SEL = [
    '[data-testid="favourites-button"]',
    '[data-testid="favourite-button"]',
    '[data-testid="observed-offer"]',
    '[data-testid*="favourit"]',
    '[data-testid*="observed"]',
    '[aria-label*="avoryt"]',
    '[aria-label*="Obserwuj"]',
    '[aria-label*="obserwuj"]',
    'button[class*="FavouriteButton"]',
    'button[class*="ObservedButton"]',
    'button[class*="favourite"]',
    'button[class*="favorite"]',
    '[data-cy*="favourit"]',
].join(',');

__BAN.CARD_SELS = [
    '[data-cy="l-card"]',
    'article[data-id]',
    '[data-testid="listing-ad"]',
    '[data-testid="ad-card"]',
    '[data-testid*="listing"]',
    '[data-testid*="AdCard"]',
    '[class*="ooa-"][class*="card"]',
    '[class*="offer-item"]',
    '[class*="card"]',
    '[data-testid*="card"]',
];

__BAN.OBSERVER_SELS = [
    '[data-cy="l-card"]',
    '[class*="offer-item"]',
    '[class*="ooa-"][class*="card"]',
];

__BAN.LISTING_PATTERNS = [
    'olx.pl',
    'olx',
    '/oferta/',
];

__BAN.positionChip = function(chip, card) {
    const heart = card.querySelector(__BAN.HEART_SEL);
    if (heart) {
        const hr = heart.getBoundingClientRect();
        const top = hr.top + (hr.height - 24) / 2;
        const left = hr.left - chip.offsetWidth - 6;
        chip.style.top = Math.round(top) + 'px';
        chip.style.left = Math.round(left) + 'px';
        return;
    }
    const cardRect = card.getBoundingClientRect();
    chip.style.top = Math.round(cardRect.top + 8) + 'px';
    chip.style.left = Math.round(cardRect.right - 90) + 'px';
};

__BAN.init();

})();