// ── OLX Site Module ──────────────────────────────────────────────────────────
// Sets OLX-specific config on __BAN, then inits shared engine.
// Runs only on https://*.olx.pl/* (see manifest.json).
// ──────────────────────────────────────────────────────────────────────────────

(function() {

console.log('[OLX Ban] OLX site module loaded');

window.__BAN = window.__BAN || {};

__BAN.SITE         = 'olx';
__BAN.CHIP_POS     = 'right';
__BAN.SEARCH_ORDER = 'created_at:desc';

__BAN.PRICE_SEL = '[data-testid="ad-price"]';

__BAN.HEART_SEL = [
    '[data-testid="favourites-button"]',
    '[data-testid="favourite-button"]',
    '[data-testid="observed-offer"]',
    '[data-testid*="favourit"]',
    '[data-testid*="observed"]',
    '[aria-label*="avoryt"]',
    '[aria-label*="Obserwuj"]',
    '[aria-label*="obserwuj"]',
    'button[class*="FavouriteButton"]',
    'button[class*="ObservedButton"]',
    'button[class*="favourite"]',
    'button[class*="favorite"]',
    '[data-cy*="favourit"]',
].join(',');

__BAN.CARD_SELS = [
    '[data-cy="l-card"]',
    'article[data-id]',
    '[data-testid="listing-ad"]',
    '[data-testid="ad-card"]',
    '[data-testid*="listing"]',
    '[data-testid*="AdCard"]',
    '[class*="ooa-"][class*="card"]',
    '[class*="offer-item"]',
    '[class*="card"]',
    '[data-testid*="card"]',
];

__BAN.init();

})();