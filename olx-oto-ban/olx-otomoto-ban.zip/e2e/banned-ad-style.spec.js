const { test, expect } = require('@playwright/test');
const path = require('path');

const testPage = 'file://' + path.resolve(__dirname, 'test-cards.html');

test.describe('applyFade - banned ad style', () => {

    test.beforeEach(async ({ page }) => {
        await page.goto(testPage);
        await page.evaluate(() => {
            window.applyFade = (card, isBanned) => {
                if (!card) return;
                if (window.bannedAdStyle === 'collapse') {
                    if (isBanned) {
                        card.style.maxHeight = '28px';
                        card.style.overflow = 'hidden';
                        card.style.minHeight = '0';
                    } else {
                        card.style.maxHeight = '';
                        card.style.overflow = '';
                        card.style.minHeight = '';
                    }
                } else {
                    card.style.opacity = isBanned ? '0.35' : '';
                    card.style.filter = isBanned ? 'grayscale(1)' : '';
                }
            };
        });
    });

    test('grey mode applies opacity and grayscale', async ({ page }) => {
        await page.evaluate(() => { window.bannedAdStyle = 'grey'; });

        const card1 = page.locator('#card1');
        await card1.evaluate((el) => window.applyFade(el, true));

        await expect(card1).toHaveCSS('opacity', '0.35');
        await expect(card1).toHaveCSS('filter', 'grayscale(1)');
    });

    test('grey mode clears styles on unban', async ({ page }) => {
        await page.evaluate(() => { window.bannedAdStyle = 'grey'; });

        const card1 = page.locator('#card1');
        await card1.evaluate((el) => window.applyFade(el, true));
        await card1.evaluate((el) => window.applyFade(el, false));

        await expect(card1).toHaveCSS('opacity', '1');
        await expect(card1).toHaveCSS('filter', 'none');
    });

    test('collapse mode sets max-height and overflow hidden', async ({ page }) => {
        await page.evaluate(() => { window.bannedAdStyle = 'collapse'; });

        const card1 = page.locator('#card1');
        await card1.evaluate((el) => window.applyFade(el, true));

        await expect(card1).toHaveCSS('max-height', '28px');
        await expect(card1).toHaveCSS('overflow', 'hidden');
        await expect(card1).toHaveCSS('min-height', '0px');
    });

    test('collapse mode shows title text while collapsed', async ({ page }) => {
        await page.evaluate(() => { window.bannedAdStyle = 'collapse'; });

        const card1 = page.locator('#card1');
        await card1.evaluate((el) => window.applyFade(el, true));

        const title = card1.locator('a');
        await expect(title).toBeVisible();
    });

    test('collapse mode clears styles on unban', async ({ page }) => {
        await page.evaluate(() => { window.bannedAdStyle = 'collapse'; });

        const card1 = page.locator('#card1');
        await card1.evaluate((el) => window.applyFade(el, true));
        await card1.evaluate((el) => window.applyFade(el, false));

        await expect(card1).toHaveCSS('max-height', 'none');
        await expect(card1).toHaveCSS('overflow', 'visible');
        await expect(card1).toHaveCSS('min-height', '0px');
    });

    test('does nothing for null card', async ({ page }) => {
        const result = await page.evaluate(() => {
            window.applyFade(null, true);
            return 'no error';
        });
        expect(result).toBe('no error');
    });

    test('applies to multiple cards independently', async ({ page }) => {
        await page.evaluate(() => { window.bannedAdStyle = 'collapse'; });

        const card1 = page.locator('#card1');
        const card2 = page.locator('#card2');

        await card1.evaluate((el) => window.applyFade(el, true));
        await card2.evaluate((el) => window.applyFade(el, false));

        await expect(card1).toHaveCSS('max-height', '28px');
        await expect(card2).toHaveCSS('max-height', 'none');

        await card2.evaluate((el) => window.applyFade(el, true));
        await expect(card2).toHaveCSS('max-height', '28px');
    });

});
