const { test, expect } = require('@playwright/test');
const path = require('path');

const testPage = 'file://' + path.resolve(__dirname, 'test-cards.html');

test.describe('banned ad style', () => {

    test.beforeEach(async ({ page }) => {
        await page.goto(testPage);
        await page.evaluate(() => {
            const collapseState = new Map();

            window.setMode = (mode) => { window.bannedAdStyle = mode; };

            function getRatingStyle(v) {
                if (v === 3) return { color: '#ff2b2b', label: '★' };
                if (v === 2) return { color: '#ffd400', label: '★' };
                if (v === 1) return { color: '#1e90ff', label: '★' };
                return { color: 'rgba(255,255,255,0.7)', label: '☆' };
            }

            function hideCard(card) {
                card.style.setProperty('height', '0', 'important');
                card.style.setProperty('min-height', '0', 'important');
                card.style.setProperty('max-height', '0', 'important');
                card.style.overflow = 'hidden';
                card.style.padding = '0';
                card.style.margin = '0';
                card.style.border = 'none';
                card.style.visibility = 'hidden';
                card.style.pointerEvents = 'none';
            }

            function showCard(card) {
                card.style.height = '';
                card.style.minHeight = '';
                card.style.maxHeight = '';
                card.style.overflow = '';
                card.style.padding = '';
                card.style.margin = '';
                card.style.border = '';
                card.style.visibility = '';
                card.style.pointerEvents = '';
            }

            window.applyFade = (card, isBanned, titleText, dbKey, data) => {
                if (!card) return;
                data = data || {};
                if (window.bannedAdStyle === 'collapse' && isBanned) {
                    const existing = collapseState.get(dbKey);
                    if (existing) {
                        if (existing.expanded) {
                            showCard(card);
                            card.style.opacity = '0.35';
                            card.style.filter = 'grayscale(1)';
                            const bar = document.querySelector(`.olx-ban-collapse-bar[data-db-key="${dbKey}"]`);
                            if (bar) {
                                const btn = bar.querySelector('.olx-ban-collapse-toggle');
                                if (btn) btn.textContent = 'Collapse';
                            }
                            const chip = document.querySelector(`.script-chip[data-db-key="${dbKey}"]`);
                            if (chip) chip.style.display = '';
                        } else {
                            hideCard(card);
                            const chip = document.querySelector(`.script-chip[data-db-key="${dbKey}"]`);
                            if (chip) chip.style.display = 'none';
                        }
                        return;
                    }

                    hideCard(card);
                    const id = dbKey.split(':')[1] || '';

                    const bar = document.createElement('div');
                    bar.className = 'olx-ban-collapse-bar';
                    bar.setAttribute('data-db-key', dbKey);
                    bar.setAttribute('data-id', id);
                    bar.style.cssText = [
                        'display:flex',
                        'align-items:center',
                        'gap:6px',
                        'padding:6px 10px',
                        'margin:8px 0',
                        'background:rgba(180,0,0,0.18)',
                        'border:1px solid rgba(180,0,0,0.35)',
                        'border-radius:6px',
                        'font-family:sans-serif',
                        'font-size:12px',
                    ].join(';');

                    const r = getRatingStyle(data.rating);
                    const star = document.createElement('span');
                    star.className = 'olx-ban-collapse-star';
                    star.textContent = r.label;
                    star.style.cssText = [
                        'font-size:16px',
                        'color:' + r.color,
                        'line-height:1',
                        'cursor:pointer',
                        'user-select:none',
                        'flex-shrink:0',
                    ].join(';');
                    bar.appendChild(star);

                    const commentLabel = document.createElement('span');
                    commentLabel.className = 'olx-ban-collapse-comment';
                    commentLabel.textContent = data.comment || '';
                    commentLabel.style.cssText = [
                        'font-size:9px',
                        'font-weight:' + (data.comment ? 'bold' : 'normal'),
                        'color:#fff7b2',
                        'background:rgba(255,247,178,0.16)',
                        'border:1px solid rgba(255,247,178,0.45)',
                        'border-radius:999px',
                        'padding:' + (data.comment ? '1px 5px' : '0'),
                        'max-width:70px',
                        'white-space:nowrap',
                        'overflow:hidden',
                        'text-overflow:ellipsis',
                        'line-height:1.2',
                        'flex-shrink:0',
                    ].join(';');
                    bar.appendChild(commentLabel);

                    const title = document.createElement('span');
                    title.textContent = titleText || '(no title)';
                    title.style.cssText = [
                        'flex:1',
                        'overflow:hidden',
                        'text-overflow:ellipsis',
                        'white-space:nowrap',
                        'color:rgba(255,255,255,0.85)',
                        'font-weight:bold',
                    ].join(';');
                    bar.appendChild(title);

                    const btn = document.createElement('button');
                    btn.className = 'olx-ban-collapse-toggle';
                    btn.textContent = 'Expand';
                    btn.style.cssText = [
                        'background:#cc0000',
                        'color:white',
                        'border:none',
                        'border-radius:4px',
                        'padding:4px 10px',
                        'cursor:pointer',
                        'font-size:11px',
                        'font-weight:bold',
                        'line-height:1.4',
                        'flex-shrink:0',
                    ].join(';');
                    btn.addEventListener('click', () => {
                        const state = collapseState.get(dbKey);
                        if (!state) return;
                        const barEl = document.querySelector(`.olx-ban-collapse-bar[data-db-key="${dbKey}"]`);
                        const btnEl = barEl?.querySelector('.olx-ban-collapse-toggle');
                        const chipEl = document.querySelector(`.script-chip[data-db-key="${dbKey}"]`);
                        if (state.expanded) {
                            hideCard(state.card);
                            if (btnEl) btnEl.textContent = 'Expand';
                            state.expanded = false;
                            if (chipEl) chipEl.style.display = 'none';
                        } else {
                            showCard(state.card);
                            state.card.style.opacity = '0.35';
                            state.card.style.filter = 'grayscale(1)';
                            if (btnEl) btnEl.textContent = 'Collapse';
                            state.expanded = true;
                            if (chipEl) chipEl.style.display = '';
                        }
                    });
                    bar.appendChild(btn);

                    card.parentNode.insertBefore(bar, card);
                    collapseState.set(dbKey, { expanded: false, card });
                } else if (window.bannedAdStyle === 'collapse' && !isBanned) {
                    showCard(card);
                    card.style.opacity = '';
                    card.style.filter = '';
                    const bar = document.querySelector(`.olx-ban-collapse-bar[data-db-key="${dbKey}"]`);
                    if (bar) bar.remove();
                    collapseState.delete(dbKey);
                    const chip = document.querySelector(`.script-chip[data-db-key="${dbKey}"]`);
                    if (chip) chip.style.display = '';
                } else {
                    const bar = document.querySelector(`.olx-ban-collapse-bar[data-db-key="${dbKey}"]`);
                    if (bar) {
                        const state = collapseState.get(dbKey);
                        if (state && state.card) {
                            showCard(state.card);
                            state.card.style.opacity = '';
                            state.card.style.filter = '';
                        }
                        bar.remove();
                        collapseState.delete(dbKey);
                    }
                    const chip = document.querySelector(`.script-chip[data-db-key="${dbKey}"]`);
                    if (chip) chip.style.display = '';
                    card.style.opacity = isBanned ? '0.35' : '';
                    card.style.filter = isBanned ? 'grayscale(1)' : '';
                }
            };

            window.removeAllCollapseBars = () => {
                document.querySelectorAll('.olx-ban-collapse-bar').forEach((bar) => {
                    const key = bar.getAttribute('data-db-key');
                    if (key) {
                        const state = collapseState.get(key);
                        if (state && state.card) {
                            showCard(state.card);
                            state.card.style.opacity = '';
                            state.card.style.filter = '';
                        }
                        const chip = document.querySelector(`.script-chip[data-db-key="${key}"]`);
                        if (chip) chip.style.display = '';
                    }
                    bar.remove();
                });
                collapseState.clear();
            };
        });
    });

    test('grey mode applies opacity and grayscale', async ({ page }) => {
        await page.evaluate(() => window.setMode('grey'));
        const card1 = page.locator('#card1');
        await card1.evaluate((el) => window.applyFade(el, true));
        await expect(card1).toHaveCSS('opacity', '0.35');
        await expect(card1).toHaveCSS('filter', 'grayscale(1)');
    });

    test('grey mode clears styles on unban', async ({ page }) => {
        await page.evaluate(() => window.setMode('grey'));
        const card1 = page.locator('#card1');
        await card1.evaluate((el) => window.applyFade(el, true));
        await card1.evaluate((el) => window.applyFade(el, false));
        await expect(card1).toHaveCSS('opacity', '1');
        await expect(card1).toHaveCSS('filter', 'none');
    });

    test('collapse bar contains star and comment', async ({ page }) => {
        await page.evaluate(() => window.setMode('collapse'));
        const card1 = page.locator('#card1');
        await card1.evaluate((el) => window.applyFade(el, true, 'iPhone 13', 'olx:abc123', { rating: 3, comment: 'spam' }));
        const bar = page.locator('.olx-ban-collapse-bar');
        await expect(bar.locator('.olx-ban-collapse-star')).toBeVisible();
        await expect(bar.locator('.olx-ban-collapse-comment')).toHaveText('spam');
        await expect(bar.locator('.olx-ban-collapse-toggle')).toHaveText('Expand');
        const title = bar.locator('span').filter({ hasText: 'iPhone 13' });
        await expect(title).toBeVisible();
    });

    test('collapse bar shows empty comment and no rating star', async ({ page }) => {
        await page.evaluate(() => window.setMode('collapse'));
        const card1 = page.locator('#card1');
        await card1.evaluate((el) => window.applyFade(el, true, 'iPhone', 'olx:abc123', {}));
        const bar = page.locator('.olx-ban-collapse-bar');
        await expect(bar.locator('.olx-ban-collapse-star')).toHaveText('☆');
        await expect(bar.locator('.olx-ban-collapse-comment')).toHaveText('');
    });

    test('expand shows card greyed out and hides chip then shows it', async ({ page }) => {
        await page.evaluate(() => window.setMode('collapse'));
        const card1 = page.locator('#card1');
        await card1.evaluate((el) => window.applyFade(el, true, 'iPhone 13', 'olx:abc123', { rating: 2, comment: 'test' }));

        await page.evaluate(() => {
            const btn = document.querySelector('.olx-ban-collapse-toggle');
            if (btn) btn.click();
        });

        await expect(card1).toHaveCSS('visibility', 'visible');
        await expect(card1).toHaveCSS('opacity', '0.35');
        await expect(card1).toHaveCSS('filter', 'grayscale(1)');
        await expect(page.locator('.olx-ban-collapse-toggle')).toHaveText('Collapse');
    });

    test('collapse button hides card again', async ({ page }) => {
        await page.evaluate(() => window.setMode('collapse'));
        const card1 = page.locator('#card1');
        await card1.evaluate((el) => window.applyFade(el, true, 'iPhone 13', 'olx:abc123', { rating: 3 }));
        await page.evaluate(() => document.querySelector('.olx-ban-collapse-toggle').click());
        await page.evaluate(() => document.querySelector('.olx-ban-collapse-toggle').click());
        await expect(card1).toHaveCSS('visibility', 'hidden');
        await expect(page.locator('.olx-ban-collapse-toggle')).toHaveText('Expand');
    });

    test('unban restores card and removes bar', async ({ page }) => {
        await page.evaluate(() => window.setMode('collapse'));
        const card1 = page.locator('#card1');
        await card1.evaluate((el) => window.applyFade(el, true, 'Title', 'olx:abc123', { comment: 'x' }));
        await expect(page.locator('.olx-ban-collapse-bar')).toBeVisible();
        await card1.evaluate((el) => window.applyFade(el, false, '', 'olx:abc123'));
        await expect(page.locator('.olx-ban-collapse-bar')).toHaveCount(0);
        await expect(card1).toHaveCSS('visibility', 'visible');
        await expect(card1).toHaveCSS('opacity', '1');
    });

    test('switching to grey removes all collapse bars and restores cards', async ({ page }) => {
        await page.evaluate(() => window.setMode('collapse'));
        const card1 = page.locator('#card1');
        const card2 = page.locator('#card2');
        await card1.evaluate((el) => window.applyFade(el, true, 'Title 1', 'key1', {}));
        await card2.evaluate((el) => window.applyFade(el, true, 'Title 2', 'key2', {}));
        await expect(page.locator('.olx-ban-collapse-bar')).toHaveCount(2);
        await page.evaluate(() => {
            window.removeAllCollapseBars();
            window.setMode('grey');
        });
        await expect(page.locator('.olx-ban-collapse-bar')).toHaveCount(0);
        await expect(card1).toHaveCSS('visibility', 'visible');
        await expect(card2).toHaveCSS('visibility', 'visible');
    });

    test('grey mode has no collapse bars', async ({ page }) => {
        await page.evaluate(() => window.setMode('grey'));
        const card1 = page.locator('#card1');
        await card1.evaluate((el) => window.applyFade(el, true));
        await expect(page.locator('.olx-ban-collapse-bar')).toHaveCount(0);
    });

});
