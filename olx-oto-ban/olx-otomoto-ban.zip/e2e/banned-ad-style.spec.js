const { test, expect } = require('@playwright/test');
const path = require('path');

const testPage = 'file://' + path.resolve(__dirname, 'test-cards.html');

test.describe('banned ad style', () => {

    test.beforeEach(async ({ page }) => {
        await page.goto(testPage);
        await page.evaluate(() => {
            const collapseState = new Map();

            window.setMode = (mode) => { window.bannedAdStyle = mode; };

            window.applyFade = (card, isBanned, titleText, dbKey) => {
                if (!card) return;
                if (window.bannedAdStyle === 'collapse' && isBanned) {
                    collapseCard(card, dbKey, titleText || '');
                } else if (window.bannedAdStyle === 'collapse' && !isBanned) {
                    restoreCard(card, dbKey);
                } else {
                    removeCollapseBar(dbKey);
                    card.style.opacity = isBanned ? '0.35' : '';
                    card.style.filter = isBanned ? 'grayscale(1)' : '';
                }
            };

            function collapseCard(card, dbKey, titleText) {
                const existing = collapseState.get(dbKey);
                if (existing) {
                    if (existing.expanded) {
                        card.style.display = '';
                        card.style.opacity = '0.35';
                        card.style.filter = 'grayscale(1)';
                        const bar = document.querySelector(`.olx-ban-collapse-bar[data-db-key="${dbKey}"]`);
                        if (bar) {
                            const btn = bar.querySelector('button');
                            if (btn) btn.textContent = 'Collapse';
                        }
                    } else {
                        card.style.display = 'none';
                    }
                    return;
                }

                card.style.display = 'none';
                const bar = document.createElement('div');
                bar.className = 'olx-ban-collapse-bar';
                bar.setAttribute('data-db-key', dbKey);
                bar.style.cssText = [
                    'display:flex',
                    'align-items:center',
                    'gap:8px',
                    'padding:8px 12px',
                    'margin:8px 0',
                    'background:rgba(180,0,0,0.18)',
                    'border:1px solid rgba(180,0,0,0.35)',
                    'border-radius:6px',
                    'font-family:sans-serif',
                    'font-size:13px',
                ].join(';');

                const title = document.createElement('span');
                title.textContent = titleText || '(no title)';
                title.style.cssText = [
                    'flex:1',
                    'overflow:hidden',
                    'text-overflow:ellipsis',
                    'white-space:nowrap',
                    'color:rgba(255,255,255,0.85)',
                    'font-weight:bold',
                ].join(';');
                bar.appendChild(title);

                const btn = document.createElement('button');
                btn.textContent = 'Expand';
                btn.style.cssText = [
                    'background:#cc0000',
                    'color:white',
                    'border:none',
                    'border-radius:4px',
                    'padding:4px 10px',
                    'cursor:pointer',
                    'font-size:11px',
                    'font-weight:bold',
                    'line-height:1.4',
                    'flex-shrink:0',
                ].join(';');
                btn.addEventListener('click', () => {
                    const state = collapseState.get(dbKey);
                    if (!state) return;
                    const barEl = document.querySelector(`.olx-ban-collapse-bar[data-db-key="${dbKey}"]`);
                    const btnEl = barEl?.querySelector('button');
                    if (state.expanded) {
                        state.card.style.display = 'none';
                        if (btnEl) btnEl.textContent = 'Expand';
                        state.expanded = false;
                    } else {
                        state.card.style.display = '';
                        state.card.style.opacity = '0.35';
                        state.card.style.filter = 'grayscale(1)';
                        if (btnEl) btnEl.textContent = 'Collapse';
                        state.expanded = true;
                    }
                });
                bar.appendChild(btn);

                card.parentNode.insertBefore(bar, card);
                collapseState.set(dbKey, { expanded: false, card });
            }

            function restoreCard(card, dbKey) {
                card.style.display = '';
                card.style.opacity = '';
                card.style.filter = '';
                removeCollapseBar(dbKey);
            }

            function removeCollapseBar(dbKey) {
                if (!dbKey) return;
                const bar = document.querySelector(`.olx-ban-collapse-bar[data-db-key="${dbKey}"]`);
                if (bar) bar.remove();
                collapseState.delete(dbKey);
            }

            function removeAllCollapseBars() {
                document.querySelectorAll('.olx-ban-collapse-bar').forEach((bar) => bar.remove());
                collapseState.clear();
            }

            window.removeAllCollapseBars = removeAllCollapseBars;
            window.collapseState = collapseState;
        });
    });

    test('grey mode applies opacity and grayscale', async ({ page }) => {
        await page.evaluate(() => window.setMode('grey'));
        const card1 = page.locator('#card1');
        await card1.evaluate((el) => window.applyFade(el, true));
        await expect(card1).toHaveCSS('opacity', '0.35');
        await expect(card1).toHaveCSS('filter', 'grayscale(1)');
    });

    test('grey mode clears styles on unban', async ({ page }) => {
        await page.evaluate(() => window.setMode('grey'));
        const card1 = page.locator('#card1');
        await card1.evaluate((el) => window.applyFade(el, true));
        await card1.evaluate((el) => window.applyFade(el, false));
        await expect(card1).toHaveCSS('opacity', '1');
        await expect(card1).toHaveCSS('filter', 'none');
    });

    test('collapse mode hides card and shows bar with title', async ({ page }) => {
        await page.evaluate(() => window.setMode('collapse'));
        const card1 = page.locator('#card1');
        await card1.evaluate((el) => window.applyFade(el, true, 'iPhone 13 - świetny stan', 'olx:abc123'));
        await expect(card1).toHaveCSS('display', 'none');
        const bar = page.locator('.olx-ban-collapse-bar');
        await expect(bar).toBeVisible();
        await expect(bar.locator('span')).toHaveText('iPhone 13 - świetny stan');
        await expect(bar.locator('button')).toHaveText('Expand');
    });

    test('collapse mode - expand shows card greyed out', async ({ page }) => {
        await page.evaluate(() => window.setMode('collapse'));
        const card1 = page.locator('#card1');
        await card1.evaluate((el) => window.applyFade(el, true, 'iPhone 13', 'olx:abc123'));
        await page.evaluate(() => {
            const btn = document.querySelector('.olx-ban-collapse-bar button');
            if (btn) btn.click();
        });
        await expect(card1).not.toHaveCSS('display', 'none');
        await expect(card1).toHaveCSS('opacity', '0.35');
        await expect(card1).toHaveCSS('filter', 'grayscale(1)');
        const bar = page.locator('.olx-ban-collapse-bar button');
        await expect(bar).toHaveText('Collapse');
    });

    test('collapse mode - collapse button hides card again', async ({ page }) => {
        await page.evaluate(() => window.setMode('collapse'));
        const card1 = page.locator('#card1');
        await card1.evaluate((el) => window.applyFade(el, true, 'iPhone 13', 'olx:abc123'));
        await page.evaluate(() => document.querySelector('.olx-ban-collapse-bar button').click());
        await page.evaluate(() => document.querySelector('.olx-ban-collapse-bar button').click());
        await expect(card1).toHaveCSS('display', 'none');
        await expect(page.locator('.olx-ban-collapse-bar button')).toHaveText('Expand');
    });

    test('collapse mode - unban restores card and removes bar', async ({ page }) => {
        await page.evaluate(() => window.setMode('collapse'));
        const card1 = page.locator('#card1');
        await card1.evaluate((el) => window.applyFade(el, true, 'Title', 'olx:abc123'));
        await expect(page.locator('.olx-ban-collapse-bar')).toBeVisible();
        await card1.evaluate((el) => window.applyFade(el, false, '', 'olx:abc123'));
        await expect(page.locator('.olx-ban-collapse-bar')).toHaveCount(0);
        await expect(card1).not.toHaveCSS('display', 'none');
        await expect(card1).toHaveCSS('opacity', '1');
    });

    test('switching to grey removes all collapse bars', async ({ page }) => {
        await page.evaluate(() => window.setMode('collapse'));
        const card1 = page.locator('#card1');
        const card2 = page.locator('#card2');
        await card1.evaluate((el) => window.applyFade(el, true, 'Title 1', 'key1'));
        await card2.evaluate((el) => window.applyFade(el, true, 'Title 2', 'key2'));
        await expect(page.locator('.olx-ban-collapse-bar')).toHaveCount(2);
        await page.evaluate(() => {
            window.removeAllCollapseBars();
            window.setMode('grey');
        });
        await expect(page.locator('.olx-ban-collapse-bar')).toHaveCount(0);
    });

    test('grey mode has no collapse bars', async ({ page }) => {
        await page.evaluate(() => window.setMode('grey'));
        const card1 = page.locator('#card1');
        await card1.evaluate((el) => window.applyFade(el, true));
        await expect(page.locator('.olx-ban-collapse-bar')).toHaveCount(0);
    });

});
