// ── Shared Engine ────────────────────────────────────────────────────────────
// Loaded by both OLX and Otomoto content scripts.
// Site-specific config is set on window.__BAN by the site module before init().
// ──────────────────────────────────────────────────────────────────────────────

(function() {

console.log('[OLX Ban] Shared engine loaded');

// ── Config (site module sets overrides before init) ─────────────────────────
window.__BAN = window.__BAN || {};

__BAN.SITE             = '';
__BAN.HEART_SEL        = '';
__BAN.CARD_SELS        = [];
__BAN.CHIP_POS         = 'right'; // default chip position when no heart btn
__BAN.SEARCH_ORDER     = 'created_at:desc';

// Legacy getSite() — returns __BAN.SITE (set by site module)
function getSite() { return __BAN.SITE; }

function extractSiteFromUrl(url) {
    if (url.includes('.olx.pl') || url.includes('//olx.pl')) return 'olx';
    if (url.includes('.otomoto.pl') || url.includes('//otomoto.pl')) return 'otomoto';
    if (url.includes('olx')) return 'olx';
    return 'otomoto';
}

// ── User config (loaded from background) ─────────────────────────────────────
const CONFIG = {
    maxCommentLen: 50,
    dbKey: 'global_listing_db',
    bannedAdStyle: 'grey',
    collapseDelay: 2000,
};

// ── Local state ──────────────────────────────────────────────────────────────
let db = {};
let suppressRender = false;
const collapseState = new Map();

// ── URL helpers ──────────────────────────────────────────────────────────────
function extractId(url) {
    const clean = url.split('?')[0].split('#')[0];
    let m = clean.match(/(?:^|[-_\/])id([A-Za-z0-9]+?)(?:\.html)?$/i);
    if (m) return m[1];
    m = clean.match(/\/oferta\/([A-Za-z0-9]+)(?:\.html)?$/i);
    if (m) return m[1];
    m = clean.match(/\/d\/oferta\/([A-Za-z0-9]+)(?:\.html)?$/i);
    if (m) return m[1];
    return null;
}

function getCurrentId() {
    return extractId(location.href);
}

function makeKeyFromUrl(url) {
    const id = extractId(url);
    if (!id) return null;
    return extractSiteFromUrl(url) + ':' + id;
}

function makeKey(id) {
    return getSite() + ':' + id;
}

function now() {
    return new Date().toISOString();
}

function formatDate(iso) {
    if (!iso) return '';
    const d = new Date(iso);
    return [d.getDate(), d.getMonth() + 1, d.getFullYear()]
        .map(n => String(n).padStart(2, '0'))
        .join('.')
        + ', '
        + [d.getHours(), d.getMinutes(), d.getSeconds()]
            .map(n => String(n).padStart(2, '0'))
            .join(':');
}

// ── Messaging (to background worker) ─────────────────────────────────────────
function sendMessage(action, payload = {}) {
    return new Promise((resolve, reject) => {
        chrome.runtime.sendMessage({ action, payload }, (response) => {
            if (chrome.runtime.lastError) {
                reject(new Error(chrome.runtime.lastError.message));
            } else if (response?.error) {
                reject(new Error(response.error));
            } else {
                resolve(response);
            }
        });
    });
}

async function loadDB() {
    const response = await sendMessage('getDB');
    db = response.db || {};
    return db;
}

async function saveDB(changedKeys) {
    await sendMessage('saveDB', { db, changedKeys });
}

// ── Write helpers ────────────────────────────────────────────────────────────
async function writeEntry(key, patch) {
    if (!db[key]) db[key] = {};
    Object.assign(db[key], patch, { updatedAt: now() });
    await saveDB([key]);
}

function normalizeComment(value) {
    return String(value || '')
        .replace(/\r?\n/g, ' ')
        .replace(/[\t ]+/g, ' ')
        .slice(0, CONFIG.maxCommentLen);
}

async function setComment(id, value) {
    const normalized = normalizeComment(value);
    const key = makeKey(id);
    const current = (db[key] || {}).comment || '';
    if (current === normalized) return;
    await writeEntry(key, { id, site: getSite(), comment: normalized });
    updateVisibleComment(key, normalized);
}

async function setCommentByKey(id, dbKey, value) {
    const normalized = normalizeComment(value);
    const current = (db[dbKey] || {}).comment || '';
    if (current === normalized) return;
    const site = dbKey.split(':')[0];
    await writeEntry(dbKey, { id, site, comment: normalized });
    updateVisibleComment(dbKey, normalized);
}

// ── Actions ──────────────────────────────────────────────────────────────────
async function updateViewed() {
    const id = getCurrentId();
    if (!id) return;
    const key = makeKey(id);
    await writeEntry(key, { id, site: getSite(), viewedAt: now() });
}

async function ban(id) {
    await writeEntry(makeKey(id), {
        id,
        site: getSite(),
        banned: true,
        status: '',
        bannedAt: now(),
    });
    render();
}

async function unban(id) {
    await writeEntry(makeKey(id), { banned: false, status: 'D' });
    render();
}

async function banByKey(id, dbKey) {
    const site = dbKey.split(':')[0];
    await writeEntry(dbKey, {
        id,
        site,
        banned: true,
        status: '',
        bannedAt: now(),
    });
    render();
}

async function unbanByKey(id, dbKey) {
    await writeEntry(dbKey, { banned: false, status: 'D' });
    render();
}

async function setRating(id) {
    const key = makeKey(id);
    const cur = (db[key] || {}).rating;
    await writeEntry(key, {
        id,
        site: getSite(),
        rating: cycleRating(cur),
        ratedAt: now(),
    });
    render();
}

async function setRatingByKey(id, dbKey) {
    const cur = (db[dbKey] || {}).rating;
    const site = dbKey.split(':')[0];
    await writeEntry(dbKey, {
        id,
        site,
        rating: cycleRating(cur),
        ratedAt: now(),
    });
    render();
}

function cycleRating(v) {
    if (!v) return 3;
    if (v === 3) return 2;
    if (v === 2) return 1;
    return null;
}

function getRatingStyle(v) {
    if (v === 3) return { color: '#ff2b2b', label: '★' };
    if (v === 2) return { color: '#ffd400', label: '★' };
    if (v === 1) return { color: '#1e90ff', label: '★' };
    return { color: 'rgba(255,255,255,0.7)', label: '☆' };
}

// ── Site module utilities (exposed so olx/otomoto can use them) ──────────────
__BAN.getDB = function() { return db; };
__BAN.extractId = extractId;
__BAN.getRatingStyle = getRatingStyle;
__BAN.cycleRating = cycleRating;
__BAN.normalizeComment = normalizeComment;
__BAN.banByKey = banByKey;
__BAN.unbanByKey = unbanByKey;
__BAN.setRatingByKey = setRatingByKey;
__BAN.updateVisibleComment = updateVisibleComment;
__BAN.applyFade = applyFade;
__BAN.now = now;
__BAN.render = render;
__BAN.getCardTitle = getCardTitle;
__BAN.getSite = getSite;

// ── Site-specific selectors (delegated to __BAN) ─────────────────────────────
function getHeartSelector() {
    return __BAN.HEART_SEL;
}

function getCard(a) {
    for (const sel of __BAN.CARD_SELS) {
        const card = a.closest(sel) || a.querySelector(sel);
        if (card) return card;
    }
    return null;
}

function isListingLink(a) {
    const href = (a.getAttribute('href') || '').toLowerCase();
    if (!href || href.startsWith('#') || href.startsWith('javascript:') || href.startsWith('mailto:'))
        return false;

    const id = extractId(href);
    const commonOffer = href.includes('/oferta/');

    const looksOlx =
        commonOffer ||
        href.includes('/d/oferta/') ||
        href.includes('olx.pl') ||
        href.includes('/oferta');

    const otomotoExtra = __BAN.LISTING_PATTERNS || [];
    const looksOtomoto = commonOffer || otomotoExtra.some(function(p) { return href.includes(p); });

    if (getSite() === 'otomoto') {
        return !!id ? looksOtomoto || looksOlx : looksOtomoto;
    }
    return !!id ? looksOlx || looksOtomoto : looksOlx;
}

// ── Fade ─────────────────────────────────────────────────────────────────────
function getCardTitle(card) {
    if (!card) return '';
    if (__BAN.TITLE_SEL) {
        for (const el of card.querySelectorAll(__BAN.TITLE_SEL)) {
            const t = el.textContent.trim();
            if (t) return t;
        }
    }
    const sel = 'h2, h6, h3, h4, [class*="title"] a, a[class*="title"], [data-testid*="title"] a, a[data-testid*="title"]';
    for (const el of card.querySelectorAll(sel)) {
        const t = el.textContent.trim();
        if (t) return t;
    }
    for (const a of card.querySelectorAll('a[href]')) {
        if (isListingLink(a)) {
            const t = a.textContent.trim();
            if (t) return t;
        }
    }
    return '';
}

function getDirectText(el) {
    let text = '';
    for (const node of el.childNodes) {
        if (node.nodeType === 3) text += node.textContent;
    }
    return text.trim();
}

function getCardPrice(card) {
    if (!card) return '';
    const selectors = [];
    if (__BAN.PRICE_SEL) selectors.push(__BAN.PRICE_SEL);
    selectors.push('[data-testid="ad-price"], [class*="price"]');
    for (const el of card.querySelectorAll(selectors.join(','))) {
        let t = getDirectText(el);
        if (!t) t = el.textContent.trim();
        if (t) return t;
    }
    for (const a of card.querySelectorAll('a[href]')) {
        if (isListingLink(a) && (!__BAN.TITLE_SEL || !a.matches(__BAN.TITLE_SEL))) {
            const t = a.textContent.trim();
            if (t && /\d/.test(t)) return t;
        }
    }
    return '';
}

function hideCard(card) {
    card.style.setProperty('height', '0', 'important');
    card.style.setProperty('min-height', '0', 'important');
    card.style.setProperty('max-height', '0', 'important');
    card.style.overflow = 'hidden';
    card.style.padding = '0';
    card.style.margin = '0';
    card.style.border = 'none';
    card.style.visibility = 'hidden';
    card.style.pointerEvents = 'none';
}

function showCard(card) {
    card.style.height = '';
    card.style.minHeight = '';
    card.style.maxHeight = '';
    card.style.overflow = '';
    card.style.padding = '';
    card.style.margin = '';
    card.style.border = '';
    card.style.visibility = '';
    card.style.pointerEvents = '';
}

function applyFade(card, isBanned, titleText, dbKey, data) {
    if (!card) return;
    if (CONFIG.bannedAdStyle === 'collapse' && isBanned) {
        collapseCard(card, dbKey, titleText || '', data || {});
    } else if (CONFIG.bannedAdStyle === 'collapse' && !isBanned) {
        const state = collapseState.get(dbKey);
        if (state) {
            showCard(card);
            card.style.opacity = '';
            card.style.filter = '';
            removeCollapseBar(dbKey);
        }
        const chip = document.querySelector(`.script-chip[data-db-key="${dbKey}"]`);
        if (chip) chip.style.display = '';
    } else {
        removeCollapseBar(dbKey);
        card.style.opacity = isBanned ? '0.35' : '';
        card.style.filter = isBanned ? 'grayscale(1)' : '';
    }
}

function createCollapseBarContent(bar, dbKey, id, data, titleText, priceText) {
    const r = getRatingStyle(data.rating);
    const star = document.createElement('span');
    star.className = 'olx-ban-collapse-star';
    star.textContent = r.label;
    star.style.cssText = [
        'font-size:18px',
        'color:' + r.color,
        'line-height:1',
        'cursor:pointer',
        'user-select:none',
        'flex-shrink:0',
    ].join(';');
    star.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        setRatingByKey(id, dbKey);
    });
    bar.appendChild(star);

    const commentLabel = document.createElement('span');
    commentLabel.className = 'olx-ban-collapse-comment';
    commentLabel.textContent = data.comment || '';
    commentLabel.title = data.comment || '';
    commentLabel.style.cssText = [
        'font-size:11px',
        'font-weight:' + (data.comment ? 'bold' : 'normal'),
        'color:#ffd700',
        'background:rgba(0,0,0,0.35)',
        'border:1px solid rgba(255,215,0,0.35)',
        'border-radius:999px',
        'padding:' + (data.comment ? '2px 8px' : '0'),
        'white-space:nowrap',
        'line-height:1.4',
        'flex-shrink:0',
    ].join(';');
    bar.appendChild(commentLabel);

    const title = document.createElement('span');
    title.textContent = titleText || '(no title)';
    title.style.cssText = [
        'flex:1',
        'overflow:hidden',
        'text-overflow:ellipsis',
        'white-space:nowrap',
        'color:#e8e8e8',
        'font-weight:bold',
    ].join(';');
    bar.appendChild(title);

    if (priceText) {
        const price = document.createElement('span');
        price.textContent = priceText;
        price.style.cssText = [
            'flex-shrink:0',
            'white-space:nowrap',
            'margin-left:8px',
            'color:#ffd700',
            'font-weight:bold',
        ].join(';');
        bar.appendChild(price);
    }

    const btn = document.createElement('button');
    btn.className = 'olx-ban-collapse-toggle';
    btn.textContent = 'Expand';
    btn.title = 'Show ad with grey styling';
    btn.style.cssText = [
        'background:#cc0000',
        'color:white',
        'border:none',
        'border-radius:4px',
        'padding:6px 12px',
        'cursor:pointer',
        'font-size:12px',
        'font-weight:bold',
        'line-height:1.4',
        'flex-shrink:0',
    ].join(';');
    btn.addEventListener('click', (e) => {
        e.stopPropagation();
        e.preventDefault();
        toggleCardCollapse(dbKey);
    });
    bar.appendChild(btn);
}

function buildCollapseBar(dbKey, id, data, titleText, priceText) {
    const bar = document.createElement('div');
    bar.className = 'olx-ban-collapse-bar';
    bar.setAttribute('data-db-key', dbKey);
    bar.setAttribute('data-id', id);
    bar.style.cssText = [
        'display:flex',
        'align-items:center',
        'gap:8px',
        'padding:8px 12px',
        'margin:8px 0',
        'background:rgba(40,0,0,0.75)',
        'border:1px solid rgba(180,0,0,0.5)',
        'border-radius:6px',
        'font-family:sans-serif',
        'font-size:13px',
    ].join(';');
    createCollapseBarContent(bar, dbKey, id, data, titleText, priceText);
    return bar;
}

function collapseCard(card, dbKey, titleText, data) {
    const existing = collapseState.get(dbKey);
    const priceText = getCardPrice(card);

    if (existing) {
        existing.card = card;
        if (existing.expanded) {
            showCard(card);
            card.style.opacity = '0.35';
            card.style.filter = 'grayscale(1)';
            let bar = document.querySelector(`.olx-ban-collapse-bar[data-db-key="${dbKey}"]`);
            if (bar) {
                const btn = bar.querySelector('.olx-ban-collapse-toggle');
                if (btn) btn.textContent = 'Collapse';
                if (card.parentNode && (bar.parentNode !== card.parentNode || bar.nextElementSibling !== card)) {
                    card.parentNode.insertBefore(bar, card);
                }
            } else if (card.parentNode) {
                bar = buildCollapseBar(dbKey, dbKey.split(':')[1] || '', existing.data || data, existing.titleText || titleText, existing.priceText || priceText);
                card.parentNode.insertBefore(bar, card);
                const newBtn = bar.querySelector('.olx-ban-collapse-toggle');
                if (newBtn) newBtn.textContent = 'Collapse';
            }
            const chip = document.querySelector(`.script-chip[data-db-key="${dbKey}"]`);
            if (chip) chip.style.display = '';
        } else {
            hideCard(card);
            const chip = document.querySelector(`.script-chip[data-db-key="${dbKey}"]`);
            if (chip) chip.style.display = 'none';
            let bar = document.querySelector(`.olx-ban-collapse-bar[data-db-key="${dbKey}"]`);
            if (bar) {
                if (card.parentNode && (bar.parentNode !== card.parentNode || bar.nextElementSibling !== card)) {
                    card.parentNode.insertBefore(bar, card);
                }
            } else if (card.parentNode) {
                bar = buildCollapseBar(dbKey, dbKey.split(':')[1] || '', existing.data || data, existing.titleText || titleText, existing.priceText || priceText);
                card.parentNode.insertBefore(bar, card);
            }
        }
        return;
    }

    hideCard(card);
    const id = dbKey.split(':')[1] || '';

    const bar = buildCollapseBar(dbKey, id, data, titleText, priceText);
    card.parentNode.insertBefore(bar, card);
    collapseState.set(dbKey, { expanded: false, card, data: data, titleText: titleText, priceText: priceText });
}

function toggleCardCollapse(dbKey) {
    const state = collapseState.get(dbKey);
    if (!state) return;

    const bar = document.querySelector(`.olx-ban-collapse-bar[data-db-key="${dbKey}"]`);
    if (!bar) return;

    const btn = bar.querySelector('.olx-ban-collapse-toggle');
    let card = state.card;
    const chip = document.querySelector(`.script-chip[data-db-key="${dbKey}"]`);

    if (!card || !card.parentNode) {
        const id = dbKey.split(':')[1] || '';
        let anchor = null;
        if (chip) {
            const href = chip.getAttribute('data-href');
            if (href) anchor = document.querySelector(`a[href="${CSS.escape(href)}"]`);
        }
        if (!anchor && id) {
            anchor = document.querySelector(`a[href*="/oferta/${id}"]`) || document.querySelector(`a[href*="-ID${id}"]`) || document.querySelector(`a[href*="/${id}"]`);
        }
        if (anchor) {
            const freshCard = getCard(anchor);
            if (freshCard && freshCard.parentNode) {
                card = freshCard;
                state.card = freshCard;
            }
        }
    }

    if (!card || !card.parentNode) return;

    if (state.expanded) {
        hideCard(card);
        if (btn) btn.textContent = 'Expand';
        state.expanded = false;
        if (chip) chip.style.display = 'none';
    } else {
        showCard(card);
        card.style.opacity = '0.35';
        card.style.filter = 'grayscale(1)';
        if (btn) btn.textContent = 'Collapse';
        state.expanded = true;
        if (chip) chip.style.display = '';
        if (typeof __BAN.renderInlineControls === 'function') {
            renderList();
        }
    }
    repositionChipForDbKey(dbKey);
}

function removeCollapseBar(dbKey) {
    if (!dbKey) return;
    const bar = document.querySelector(`.olx-ban-collapse-bar[data-db-key="${dbKey}"]`);
    if (bar) bar.remove();
    collapseState.delete(dbKey);
    const chip = document.querySelector(`.script-chip[data-db-key="${dbKey}"]`);
    if (chip) chip.style.display = '';
}

function removeAllCollapseBars() {
    document.querySelectorAll('.olx-ban-collapse-bar').forEach((bar) => {
        const key = bar.getAttribute('data-db-key');
        if (key) {
            const state = collapseState.get(key);
            if (state && state.card) {
                showCard(state.card);
                state.card.style.opacity = '';
                state.card.style.filter = '';
            }
            const chip = document.querySelector(`.script-chip[data-db-key="${key}"]`);
            if (chip) chip.style.display = '';
        }
        bar.remove();
    });
    collapseState.clear();
}

function repositionChipForDbKey(dbKey) {
    const state = collapseState.get(dbKey);
    const chip = document.querySelector(`.script-chip[data-db-key="${dbKey}"]`);
    if (!chip) return;
    if (typeof __BAN.positionChipInline === 'function') return;
    const target = (state && !state.expanded)
        ? document.querySelector(`.olx-ban-collapse-bar[data-db-key="${dbKey}"]`)
        : state?.card;
    if (!target) return;
    requestAnimationFrame(() => positionChip(chip, target));
}

// ── Overlay layer ────────────────────────────────────────────────────────────
function getLayer() {
    let layer = document.getElementById('olx-script-layer');
    if (!layer) {
        layer = document.createElement('div');
        layer.id = 'olx-script-layer';
        layer.style.cssText =
            'position:fixed;top:0;left:0;width:0;height:0;z-index:999998;pointer-events:none;';
        document.body.appendChild(layer);
    }
    return layer;
}

function buildChip(id, data, dbKey) {
    const chip = document.createElement('div');
    chip.className = 'script-chip';
    chip.setAttribute('data-id', id);
    chip.setAttribute('data-db-key', dbKey);
    chip.style.cssText = [
        'display:inline-flex',
        'gap:6px',
        'align-items:center',
        'background:rgba(0,0,0,0.78)',
        'border-radius:6px',
        'padding:5px 9px',
        'cursor:default',
        'font-family:sans-serif',
        'margin:4px 0 10px 0',
        'width:fit-content',
    ].join(';');

    if (data.viewedAt) {
        const eye = document.createElement('span');
        eye.textContent = '\uD83D\uDC41';
        eye.style.cssText = 'font-size:14px;line-height:1;opacity:0.9;pointer-events:none;';
        chip.appendChild(eye);
    }

    const r = getRatingStyle(data.rating);
    const star = document.createElement('span');
    star.textContent = r.label;
    star.style.cssText = 'font-size:16px;color:' + r.color + ';line-height:1;cursor:pointer;user-select:none;';
    star.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        setRatingByKey(id, dbKey);
    });
    chip.appendChild(star);

    const commentBox = document.createElement('div');
    commentBox.style.cssText = [
        'display:flex',
        'flex-direction:column',
        'align-items:flex-start',
        'gap:2px',
    ].join(';');

    const commentLabel = document.createElement('span');
    commentLabel.className = 'comment-label';
    commentLabel.textContent = data.comment || 'comment';
    commentLabel.style.cssText = [
        'font-size:11px',
        'font-weight:bold',
        'color:#fff7b2',
        'background:rgba(255,247,178,0.16)',
        'border:1px solid rgba(255,247,178,0.45)',
        'border-radius:999px',
        'padding:2px 8px',
        'white-space:nowrap',
        'overflow:hidden',
        'text-overflow:ellipsis',
        'line-height:1.4',
    ].join(';');
    commentBox.appendChild(commentLabel);

    const commentInput = document.createElement('input');
    commentInput.className = 'comment-input';
    commentInput.type = 'text';
    commentInput.id = 'comment-input-' + String(dbKey).replace(/[^a-z0-9]+/gi, '-');
    commentInput.name = commentInput.id;
    commentInput.setAttribute('autocomplete', 'off');
    commentInput.setAttribute('aria-label', 'Comment');
    commentInput.maxLength = CONFIG.maxCommentLen;
    commentInput.placeholder = 'comment';
    commentInput.value = data.comment || '';
    commentInput.title = 'Short comment (max ' + CONFIG.maxCommentLen + ' chars)';
    commentInput.style.cssText = [
        'width:100px',
        'padding:4px 6px',
        'border-radius:4px',
        'border:1px solid rgba(255,255,255,0.25)',
        'background:rgba(255,255,255,0.12)',
        'color:white',
        'font-size:11px',
        'outline:none',
        'box-sizing:border-box',
    ].join(';');

    commentInput.addEventListener('mousedown', (e) => {
        e.stopPropagation();
        suppressRender = true;
    });
    commentInput.addEventListener('pointerdown', (e) => {
        e.stopPropagation();
        suppressRender = true;
    });
    commentInput.addEventListener('focus', () => {
        suppressRender = true;
    });
    commentInput.addEventListener('keydown', () => {
        suppressRender = true;
    });
    commentInput.addEventListener('blur', () => {
        suppressRender = false;
        updateVisibleComment(dbKey, commentInput.value);
    });
    commentInput.addEventListener('input', (e) => {
        const value = normalizeComment(e.target.value);
        e.target.value = value;
        commentLabel.textContent = value || 'comment';
        setCommentByKey(id, dbKey, value);
    });

    commentBox.appendChild(commentInput);
    chip.appendChild(commentBox);

    const btn = document.createElement('button');
    btn.textContent = data.banned ? 'BANNED' : 'BAN';
    btn.style.cssText = [
        'background:' + (data.banned ? '#cc0000' : '#222'),
        'color:white',
        'border:none',
        'font-size:11px',
        'font-weight:bold',
        'padding:4px 8px',
        'border-radius:4px',
        'cursor:pointer',
        'line-height:1.4',
    ].join(';');
    btn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        data.banned ? unbanByKey(id, dbKey) : banByKey(id, dbKey);
    });
    chip.appendChild(btn);

    return chip;
}

function updateVisibleComment(dbKey, value) {
    const comment = value || '';
    document.querySelectorAll('.script-chip').forEach((chip) => {
        if (chip.getAttribute('data-db-key') !== dbKey) return;
        const label = chip.querySelector('.comment-label');
        if (label) label.textContent = comment || 'comment';
        const input = chip.querySelector('.comment-input');
        if (input && document.activeElement !== input) input.value = comment;
    });
    const bar = document.querySelector(`.olx-ban-collapse-bar[data-db-key="${dbKey}"]`);
    if (bar) {
        const label = bar.querySelector('.olx-ban-collapse-comment');
        if (label) {
            label.textContent = comment;
            label.style.fontWeight = comment ? 'bold' : 'normal';
            label.style.padding = comment ? '1px 5px' : '0';
        }
    }
}

function positionChip(chip, card) {
    if (typeof __BAN.positionChip === 'function') {
        __BAN.positionChip(chip, card);
        return;
    }
    const heart = card.querySelector(getHeartSelector());
    const cardRect = card.getBoundingClientRect();
    let top, left;

    if (heart) {
        const hr = heart.getBoundingClientRect();
        top = hr.top + (hr.height - 24) / 2;
        left = hr.left - chip.offsetWidth - 6;
        if (chip.offsetWidth === 0) left = hr.left - 80;
    } else {
        top = cardRect.top + 8;
        left = __BAN.CHIP_POS === 'left'
            ? cardRect.left + 8
            : cardRect.right - 90;
    }

    chip.style.top = Math.round(top) + 'px';
    chip.style.left = Math.round(left) + 'px';
}

function renderList() {
    const pageId = getCurrentId();

    document.querySelectorAll('.script-chip').forEach((c) => c.remove());

    if (typeof __BAN.cleanupInlineChips === 'function') {
        __BAN.cleanupInlineChips();
    }

    const seenKeys = new Set();

    document.querySelectorAll('a[href]').forEach((a) => {
        const id = extractId(a.href);
        if (!id || id === pageId) return;
        if (!isListingLink(a)) return;
        var dialogEl = a.closest('[role="dialog"]');
        if (dialogEl && !dialogEl.matches('[class*="gallery" i], [class*="lightbox" i], [class*="offer" i], [class*="listing" i], [data-testid*="gallery" i]')) return;
        if (
            a.closest('header') ||
            a.closest('nav') ||
            a.closest('#notification-hub-dropdown')
        )
            return;

        const card = getCard(a);
        if (!card) return;

        const dbKey = makeKeyFromUrl(a.href);
        if (!dbKey || seenKeys.has(dbKey)) return;
        seenKeys.add(dbKey);

        const data = db[dbKey] || {};
        const titleText = getCardTitle(card) || a.textContent;
        applyFade(card, data.banned, titleText, dbKey, data);

        if (typeof __BAN.renderInlineControls !== 'function') {
            const chip = buildChip(id, data, dbKey);
            chip.setAttribute('data-href', a.href);
            card.after(chip);
            const state = collapseState.get(dbKey);
            if (CONFIG.bannedAdStyle === 'collapse' && data.banned && state && !state.expanded) {
                chip.style.display = 'none';
            }
        }

        if (typeof __BAN.renderInlineControls === 'function') {
            const state = collapseState.get(dbKey);
            if (CONFIG.bannedAdStyle === 'collapse' && data.banned && state && state.expanded) {
                const chip = buildChip(id, data, dbKey);
                chip.setAttribute('data-href', a.href);
                card.after(chip);
            }
        }
    });

    document.querySelectorAll('.olx-ban-collapse-bar').forEach((bar) => {
        const key = bar.getAttribute('data-db-key');
        if (key && !seenKeys.has(key)) {
            bar.remove();
            collapseState.delete(key);
        }
    });

    if (typeof __BAN.renderInlineControls === 'function') {
        __BAN.renderInlineControls(db);
    }
}

function repositionAll() {
    document.querySelectorAll('.script-chip').forEach((chip) => {
        const id = chip.getAttribute('data-id');
        const href = chip.getAttribute('data-href');
        if (!id) return;

        let a = href
            ? document.querySelector('a[href="' + href + '"]') ||
              document.querySelector('a[href*="-ID' + id + '"]')
            : document.querySelector('a[href*="-ID' + id + '"]');

        if (!a) return;
        const card = getCard(a);
        if (card) positionChip(chip, card);
    });
}

// ── Detail page UI ───────────────────────────────────────────────────────────
function cleanupUI() {
    document.getElementById('ban-ui')?.remove();
    document.getElementById('ban-bar')?.remove();
}

function renderBanner(id, data) {
    if (!data.banned) return;

    const bar = document.createElement('div');
    bar.id = 'ban-bar';
    bar.style.cssText = [
        'position:fixed',
        'bottom:0',
        'left:0',
        'width:100%',
        'z-index:2147483647',
        'background:linear-gradient(90deg,#b00000,#ff2b2b)',
        'color:white',
        'display:flex',
        'align-items:center',
        'justify-content:center',
        'gap:14px',
        'padding:10px 20px',
        'box-sizing:border-box',
        'font-family:sans-serif',
        'font-size:14px',
        'font-weight:bold',
    ].join(';');

    const label = document.createElement('span');
    const commentText = data.comment ? ' | comment: ' + data.comment : '';
    label.textContent = '\uD83D\uDEAB BANNED | ID: ' + id + ' | since: ' + formatDate(data.bannedAt) + commentText;

    const ubtn = document.createElement('button');
    ubtn.textContent = 'UNBAN';
    ubtn.style.cssText =
        'background:white;color:#b00000;border:none;padding:5px 12px;border-radius:5px;cursor:pointer;font-weight:bold;font-size:13px;';
    ubtn.addEventListener('click', () => unban(id));

    bar.appendChild(label);
    bar.appendChild(ubtn);
    document.body.appendChild(bar);
}

function renderPage() {
    const id = getCurrentId();
    if (!id) return;

    updateViewed();

    const data = db[makeKey(id)] || {};

    const ui = document.createElement('div');
    ui.id = 'ban-ui';
    ui.style.cssText = [
        'position:fixed',
        'bottom:' + (data.banned ? '76px' : '20px'),
        'right:20px',
        'z-index:2147483647',
        'background:rgba(0,0,0,0.92)',
        'padding:10px 14px',
        'border-radius:10px',
        'display:flex',
        'gap:10px',
        'align-items:center',
        'font-family:sans-serif',
    ].join(';');

    const eye = document.createElement('span');
    eye.textContent = '\uD83D\uDC41';
    eye.style.cssText = 'font-size:18px;opacity:0.9;';
    ui.appendChild(eye);

    const r = getRatingStyle(data.rating);
    const star = document.createElement('span');
    star.textContent = r.label;
    star.style.cssText = 'font-size:22px;color:' + r.color + ';cursor:pointer;user-select:none;';
    star.addEventListener('click', () => setRating(id));
    ui.appendChild(star);

    const commentBox = document.createElement('div');
    commentBox.style.cssText = [
        'display:flex',
        'flex-direction:column',
        'align-items:flex-start',
        'gap:2px',
        'min-width:120px',
        'max-width:140px',
    ].join(';');

    const commentLabel = document.createElement('span');
    commentLabel.className = 'comment-label';
    commentLabel.textContent = data.comment || 'comment';
    commentLabel.style.cssText = [
        'font-size:11px',
        'color:rgba(255,255,255,0.95)',
        'white-space:nowrap',
        'overflow:hidden',
        'text-overflow:ellipsis',
        'max-width:100%',
    ].join(';');
    commentBox.appendChild(commentLabel);

    const commentInput = document.createElement('input');
    commentInput.className = 'comment-input';
    commentInput.type = 'text';
    commentInput.id = 'comment-input-' + String(id).replace(/[^a-z0-9]+/gi, '-');
    commentInput.name = commentInput.id;
    commentInput.setAttribute('autocomplete', 'off');
    commentInput.setAttribute('aria-label', 'Comment');
    commentInput.maxLength = CONFIG.maxCommentLen;
    commentInput.placeholder = 'comment';
    commentInput.value = data.comment || '';
    commentInput.title = 'Short comment (max ' + CONFIG.maxCommentLen + ' chars)';
    commentInput.style.cssText = [
        'width:100%',
        'padding:6px 8px',
        'border-radius:6px',
        'border:1px solid rgba(255,255,255,0.2)',
        'background:rgba(255,255,255,0.12)',
        'color:white',
        'font-size:12px',
        'outline:none',
        'box-sizing:border-box',
    ].join(';');

    commentInput.addEventListener('mousedown', (e) => {
        e.stopPropagation();
        suppressRender = true;
    });
    commentInput.addEventListener('pointerdown', (e) => {
        e.stopPropagation();
        suppressRender = true;
    });
    commentInput.addEventListener('focus', () => {
        suppressRender = true;
    });
    commentInput.addEventListener('keydown', () => {
        suppressRender = true;
    });
    commentInput.addEventListener('blur', () => {
        suppressRender = false;
        updateVisibleComment(makeKey(id), commentInput.value);
    });
    commentInput.addEventListener('input', (e) => {
        const value = normalizeComment(e.target.value);
        e.target.value = value;
        commentLabel.textContent = value || 'comment';
        setComment(id, value);
    });

    commentBox.appendChild(commentInput);
    ui.appendChild(commentBox);

    const btn = document.createElement('button');
    btn.textContent = data.banned ? 'UNBAN' : 'BAN';
    btn.style.cssText = [
        'background:' + (data.banned ? 'red' : '#222'),
        'color:white',
        'border:none',
        'padding:6px 12px',
        'border-radius:6px',
        'cursor:pointer',
        'font-weight:bold',
        'font-size:13px',
    ].join(';');
    btn.addEventListener('click', () => (data.banned ? unban(id) : ban(id)));
    ui.appendChild(btn);

    document.body.appendChild(ui);
    renderBanner(id, data);
}

// ── Main render ──────────────────────────────────────────────────────────────
function render() {
    if (suppressRender) return;
    cleanupUI();
    renderList();
    renderPage();
}

// ── Observers ────────────────────────────────────────────────────────────────
function isRelevantMutation(mutations) {
    const IGNORE_SEL = '.olx-ban-inline-controls, .olx-ban-collapse-bar, .script-chip, #olx-script-layer, #ban-ui, #ban-bar, .comment-input, .comment-label';
    const baseSelectors = [
        'a[href]',
        'article[data-id]',
        '[data-cy="l-card"]',
        '[class*="ooa-"][class*="card"]',
        '[class*="offer-item"]',
        '[data-testid="listing-ad"]',
        '[data-testid="ad-card"]',
        '[data-testid*="listing"]',
        '[data-testid*="AdCard"]',
        '[class*="card"]',
        '[class*="gallery"]',
        '[class*="lightbox"]',
        '[class*="modal"]',
        '[class*="overlay"]',
        '[class*="dialog"]',
        '[role="dialog"]',
    ];
    const siteSels = __BAN.OBSERVER_SELS || [];
    const selectors = [...baseSelectors, ...siteSels].join(',');

    return mutations.some((mutation) => {
        const nodes = [...mutation.addedNodes, ...mutation.removedNodes];
        if (nodes.some(function(n) { return n.nodeType === 1 && n.matches?.(IGNORE_SEL); })) return false;
        return nodes.some((node) => {
            if (!node || node.nodeType !== 1) return false;
            const el = node;
            if (el.matches?.(selectors)) return true;
            if (el.querySelector?.(selectors)) return true;
            return false;
        });
    });
}

function startObserver() {
    let scheduled = false;
    new MutationObserver((mutations) => {
        if (!isRelevantMutation(mutations)) return;
        if (scheduled) return;
        scheduled = true;
        requestAnimationFrame(() => {
            renderList();
            scheduled = false;
        });
    }).observe(document.body, { childList: true, subtree: true });
}

function startPositionWatch() {
    let rafId = null;
    const onMove = () => {
        if (rafId) return;
        rafId = requestAnimationFrame(() => {
            repositionAll();
            rafId = null;
        });
    };
    window.addEventListener('scroll', onMove, { passive: true });
    window.addEventListener('resize', onMove, { passive: true });
}

function startNavWatch() {
    let last = location.href;
    const onNav = () => {
        if (location.href !== last) {
            last = location.href;
            render();
        }
    };
    setInterval(onNav, 200);
    window.addEventListener('popstate', () => requestAnimationFrame(onNav));
    window.addEventListener('hashchange', () => requestAnimationFrame(onNav));
}

function ensureSearchOrder() {
    const u = new URL(location.href);
    if (u.searchParams.has('search[order]')) return;
    u.searchParams.set('search[order]', __BAN.SEARCH_ORDER);
    location.href = u.toString();
}

function updateEntryInPlace(dbKey) {
    const data = db[dbKey] || {};
    const chip = document.querySelector(`.script-chip[data-db-key="${dbKey}"]`);
    if (!chip) {
        if (typeof __BAN.updateInlineControls === 'function') {
            __BAN.updateInlineControls(dbKey, data);
        }
        return;
    }

    const href = chip.getAttribute('data-href');
    const id = chip.getAttribute('data-id');
    let a = null;
    if (href) {
        a = document.querySelector(`a[href="${CSS.escape(href)}"]`);
    }
    if (!a && id) {
        a = document.querySelector(`a[href*="/oferta/${id}"]`) || document.querySelector(`a[href*="-ID${id}"]`) || document.querySelector(`a[href*="/${id}"]`);
    }
    if (a) {
        const card = getCard(a);
        const titleText = getCardTitle(card) || a.textContent;
        applyFade(card, data.banned, titleText, dbKey, data);
    }

    const btn = chip.querySelector('button');
    if (btn) {
        btn.textContent = data.banned ? 'BANNED' : 'BAN';
        btn.style.background = data.banned ? '#cc0000' : '#222';
    }

    const star = chip.querySelector('span[style*="cursor:pointer"]');
    if (star) {
        const r = getRatingStyle(data.rating);
        star.textContent = r.label;
        star.style.color = r.color;
    }

    const commentLabel = chip.querySelector('.comment-label');
    const commentInput = chip.querySelector('.comment-input');
    if (commentLabel) commentLabel.textContent = data.comment || 'comment';
    if (commentInput && document.activeElement !== commentInput) commentInput.value = data.comment || '';

    const collapseBar = document.querySelector(`.olx-ban-collapse-bar[data-db-key="${dbKey}"]`);
    if (collapseBar) {
        const cStar = collapseBar.querySelector('.olx-ban-collapse-star');
        if (cStar) {
            const r = getRatingStyle(data.rating);
            cStar.textContent = r.label;
            cStar.style.color = r.color;
        }
        const cComment = collapseBar.querySelector('.olx-ban-collapse-comment');
        if (cComment) {
            cComment.textContent = data.comment || '';
            cComment.style.fontWeight = data.comment ? 'bold' : 'normal';
            cComment.style.padding = data.comment ? '1px 5px' : '0';
        }
    }

    if (typeof __BAN.updateInlineControls === 'function') {
        __BAN.updateInlineControls(dbKey);
    }
}

chrome.runtime.onMessage.addListener((request) => {
    if (request.action === 'bannedAdStyleChanged') {
        CONFIG.bannedAdStyle = request.style;
        if (request.style === 'grey') {
            removeAllCollapseBars();
        } else {
            collapseState.clear();
        }
        render();
        return;
    }
    if (request.action === 'dbUpdated') {
        loadDB().then(() => {
            const pageKey = getCurrentId() ? makeKey(getCurrentId()) : null;
            if (request.keys && request.keys.length) {
                let needsPageRender = false;
                for (const key of request.keys) {
                    if (key === pageKey) needsPageRender = true;
                    updateEntryInPlace(key);
                }
                if (needsPageRender && !suppressRender) {
                    cleanupUI();
                    renderPage();
                }
            } else {
                render();
            }
        });
    }
});

// ── Init ─────────────────────────────────────────────────────────────────────
async function loadConfig() {
    try {
        const [styleRes, delayRes] = await Promise.all([
            sendMessage('getBannedAdStyle'),
            sendMessage('getCollapseDelay'),
        ]);
        CONFIG.bannedAdStyle = styleRes.style || 'grey';
        CONFIG.collapseDelay = delayRes.delay ?? 2000;
    } catch (e) {
        console.warn('[Content] Failed to load config, using defaults:', e);
    }
}

async function init() {
    try {
        await Promise.all([loadDB(), loadConfig()]);
        ensureSearchOrder();

        const actualStyle = CONFIG.bannedAdStyle;
        CONFIG.bannedAdStyle = 'grey';
        render();
        startObserver();
        startPositionWatch();
        startNavWatch();

        if (actualStyle === 'collapse') {
            setTimeout(() => {
                CONFIG.bannedAdStyle = 'collapse';
                collapseState.clear();
                render();
            }, CONFIG.collapseDelay);
        }

        console.log('[OLX Ban] Initialized on', getSite());
    } catch (e) {
        console.error('[OLX Ban] Init error:', e);
        const errDiv = document.createElement('div');
        errDiv.style.cssText = 'position:fixed;top:10px;right:10px;z-index:999999;background:#c00;color:#fff;padding:10px 16px;border-radius:8px;font:14px sans-serif;max-width:400px;';
        errDiv.textContent = '[OLX Ban] Init error: ' + e.message;
        document.body.appendChild(errDiv);
    }
}

// Expose helpers for site modules to build custom UI
__BAN.helpers = {
    getRatingStyle: getRatingStyle,
    cycleRating: cycleRating,
    extractId: extractId,
    extractSiteFromUrl: extractSiteFromUrl,
    getHeartSelector: getHeartSelector,
    normalizeComment: normalizeComment,
    updateVisibleComment: updateVisibleComment,
    makeKeyFromUrl: makeKeyFromUrl,
    makeKey: makeKey,
    now: now,
    getCardTitle: getCardTitle,
    getCard: getCard,
    isListingLink: isListingLink,
    setRatingByKey: setRatingByKey,
    banByKey: banByKey,
    unbanByKey: unbanByKey,
    setComment: setComment,
    setCommentByKey: setCommentByKey,
};

// Expose init for site module to call after setting config
__BAN.init = init;

})();
