function sendMessage(action, payload = {}) {
    return new Promise((resolve, reject) => {
        chrome.runtime.sendMessage({ action, payload }, (response) => {
            if (chrome.runtime.lastError) {
                reject(new Error(chrome.runtime.lastError.message));
            } else if (response?.error) {
                reject(new Error(response.error));
            } else {
                resolve(response);
            }
        });
    });
}

async function loadConfig() {
    const [tokenRes, gistIdRes, hkRes] = await Promise.all([
        sendMessage('getToken'),
        sendMessage('getGistId'),
        sendMessage('getHousekeepingDays'),
    ]);
    document.getElementById('gist-token').value = tokenRes.token || '';
    document.getElementById('gist-id').value = gistIdRes.gistId || '';
    document.getElementById('housekeeping-days').value = hkRes.days || '';
}

async function saveConfig() {
    const token = document.getElementById('gist-token').value;
    const gistId = document.getElementById('gist-id').value;
    const hkDays = parseInt(document.getElementById('housekeeping-days').value, 10);

    const statusEl = document.getElementById('status');
    statusEl.className = 'status';

    try {
        await sendMessage('setToken', { token });
        await sendMessage('setGistId', { gistId });
        if (!isNaN(hkDays) && hkDays > 0) {
            await sendMessage('setHousekeepingDays', { days: hkDays });
        }
        statusEl.textContent = 'Configuration saved successfully';
        statusEl.className = 'status success';
    } catch (e) {
        statusEl.textContent = 'Error saving configuration: ' + e.message;
        statusEl.className = 'status error';
    }
}

async function syncNow() {
    const statusEl = document.getElementById('status');
    statusEl.className = 'status';
    statusEl.textContent = 'Sync triggered...';
    statusEl.className = 'status';
    statusEl.style.display = 'block';
    try {
        await sendMessage('syncNow');
        statusEl.textContent = 'Sync completed';
        statusEl.className = 'status success';
    } catch (e) {
        statusEl.textContent = 'Sync error: ' + e.message;
        statusEl.className = 'status error';
    }
}

document.getElementById('save').addEventListener('click', saveConfig);
document.getElementById('sync').addEventListener('click', syncNow);
document.addEventListener('DOMContentLoaded', loadConfig);
