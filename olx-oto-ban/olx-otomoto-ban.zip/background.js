// ── Background Service Worker ────────────────────────────────────────────────
// GitHub Gist sync engine with localStorage-only persistence
// ZERO Google ecosystem dependencies — works on all WebExtension browsers
// Firefox, Chrome, Opera, Edge, etc.

const GIST_CONFIG = {
    owner: 'piotereks',
    filename: 'olx_otomoto_db.json',
    defaultId: 'eb2ae321606877b02d4c75675b8557d4',
};

const SYNC_CONFIG = {
    tokenLsKey: 'gist_token',
    gistIdLsKey: 'gist_id',
    dbKey: 'global_listing_db',
    syncIntervalMs: 300000,  // 5 minutes = 5 * 60 * 1000
};

// Runtime state (ephemeral, lost on worker restart)
let gistId = GIST_CONFIG.defaultId;
let syncInProgress = false;
let periodicSyncTimer = null;
let lastSyncTime = 0;

// ──────────────────────────────────────────────────────────────────────────────
// STORAGE LAYER (localStorage only, no Google dependencies)
// ──────────────────────────────────────────────────────────────────────────────

function getFromStorage(key) {
    const val = localStorage.getItem(key);
    if (!val) return undefined;
    try {
        return JSON.parse(val);
    } catch {
        return val; // return as string if not JSON
    }
}

function setInStorage(key, value) {
    try {
        const toStore = typeof value === 'string' ? value : JSON.stringify(value);
        localStorage.setItem(key, toStore);
    } catch (e) {
        console.error('[BG] localStorage error:', e);
    }
}

function removeFromStorage(key) {
    localStorage.removeItem(key);
}

// ──────────────────────────────────────────────────────────────────────────────
// TOKEN MANAGEMENT (localStorage)
// ──────────────────────────────────────────────────────────────────────────────

function getToken() {
    return getFromStorage(SYNC_CONFIG.tokenLsKey) || '';
}

function saveToken(token) {
    const trimmed = token.trim();
    setInStorage(SYNC_CONFIG.tokenLsKey, trimmed);
    console.log('[BG] Token saved (length: ' + trimmed.length + ')');
}

function clearToken() {
    removeFromStorage(SYNC_CONFIG.tokenLsKey);
    console.log('[BG] Token cleared');
}

// ──────────────────────────────────────────────────────────────────────────────
// DB HELPERS (localStorage)
// ──────────────────────────────────────────────────────────────────────────────

function getDB() {
    const stored = getFromStorage(SYNC_CONFIG.dbKey);
    if (!stored) return {};
    if (typeof stored === 'object') return stored;
    try {
        return JSON.parse(stored);
    } catch (e) {
        console.warn('[BG] DB parse error:', e);
        return {};
    }
}

function saveDB(db) {
    setInStorage(SYNC_CONFIG.dbKey, db);
}

function now() {
    return new Date().toISOString();
}

// ──────────────────────────────────────────────────────────────────────────────
// MERGE LOGIC (field-level timestamp comparison)
// ──────────────────────────────────────────────────────────────────────────────

function mergeDBs(local, remote) {
    const merged = Object.assign({}, local);

    for (const [k, rv] of Object.entries(remote)) {
        const lv = local[k];
        if (!lv) {
            merged[k] = rv;
            continue;
        }

        const entry = Object.assign({}, lv);

        // Ban field: newer bannedAt timestamp wins
        const lBan = lv.bannedAt || '';
        const rBan = rv.bannedAt || '';
        if (rBan > lBan) {
            entry.banned = rv.banned;
            entry.bannedAt = rv.bannedAt;
            if (rv.status !== undefined) entry.status = rv.status;
        }

        // Rating field: newer ratedAt timestamp wins
        const lRat = lv.ratedAt || '';
        const rRat = rv.ratedAt || '';
        if (rRat > lRat) {
            entry.rating = rv.rating;
            entry.ratedAt = rv.ratedAt;
        }

        // Comment field: newer updatedAt timestamp wins
        if (rv.comment !== undefined && (rv.updatedAt || '') >= (lv.updatedAt || '')) {
            entry.comment = rv.comment;
        }

        // Viewed field: newer viewedAt timestamp wins
        const lVie = lv.viewedAt || '';
        const rVie = rv.viewedAt || '';
        if (rVie > lVie) entry.viewedAt = rv.viewedAt;

        // Metadata
        if (!entry.id && rv.id) entry.id = rv.id;
        if (!entry.site && rv.site) entry.site = rv.site;

        const lUpd = lv.updatedAt || '';
        const rUpd = rv.updatedAt || '';
        if (rUpd > lUpd) entry.updatedAt = rv.updatedAt;

        merged[k] = entry;
    }

    return merged;
}

// ──────────────────────────────────────────────────────────────────────────────
// GITHUB GIST API
// ──────────────────────────────────────────────────────────────────────────────

async function createGist(db) {
    const token = getToken();
    if (!token) throw new Error('NO_TOKEN');

    const body = {
        description: 'OLX/Otomoto listing DB (synced by WebExtension)',
        public: false,
        files: {
            [GIST_CONFIG.filename]: {
                content: JSON.stringify(db, null, 2),
            },
        },
    };

    const res = await fetch('https://api.github.com/gists', {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json',
            'Accept': 'application/vnd.github+json',
        },
        body: JSON.stringify(body),
    });

    if (!res.ok) {
        const txt = await res.text().catch(() => '<no body>');
        throw new Error(`Gist create failed: ${res.status} ${txt}`);
    }

    const data = await res.json();
    gistId = data.id;
    setInStorage(SYNC_CONFIG.gistIdLsKey, gistId);
    console.log('[BG] Created new gist. ID:', gistId);
    return data;
}

async function fetchGist() {
    if (!gistId) {
        console.warn('[BG] No Gist ID, skipping fetch');
        return null;
    }

    const token = getToken();
    if (!token) {
        console.warn('[BG] No token, cannot fetch gist');
        return null;
    }

    const res = await fetch(`https://api.github.com/gists/${gistId}`, {
        headers: {
            'Authorization': `Bearer ${token}`,
            'Accept': 'application/vnd.github+json',
        },
    });

    if (res.status === 401) {
        console.error('[BG] Gist fetch 401 — invalid token');
        clearToken();
        throw new Error('INVALID_TOKEN');
    }

    if (!res.ok) {
        const txt = await res.text().catch(() => '<no body>');
        console.warn('[BG] Gist fetch failed:', res.status, txt);
        return null;
    }

    const data = await res.json();
    const file = data.files?.[GIST_CONFIG.filename];
    if (!file || !file.content) {
        console.warn('[BG] Gist file not found');
        return null;
    }

    let parsed = null;
    try {
        parsed = JSON.parse(file.content);
    } catch (e) {
        console.warn('[BG] Failed to parse gist content:', e);
        return null;
    }

    return { db: parsed, gist: data };
}

async function pushGist(db) {
    const token = getToken();
    if (!token) throw new Error('NO_TOKEN');

    const content = JSON.stringify(db, null, 2);

    if (!gistId) {
        console.log('[BG] No gist ID, creating new gist');
        await createGist(db);
        return;
    }

    const body = {
        files: {
            [GIST_CONFIG.filename]: { content },
        },
    };

    const res = await fetch(`https://api.github.com/gists/${gistId}`, {
        method: 'PATCH',
        headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json',
            'Accept': 'application/vnd.github+json',
        },
        body: JSON.stringify(body),
    });

    if (res.status === 401) {
        console.error('[BG] Gist push 401 — invalid token');
        clearToken();
        throw new Error('INVALID_TOKEN');
    }

    if (!res.ok) {
        const txt = await res.text().catch(() => '<no body>');
        console.warn('[BG] Gist push failed:', res.status, txt);
    } else {
        console.log('[BG] Gist push successful');
    }
}

// ──────────────────────────────────────────────────────────────────────────────
// SYNC ENGINE (5-minute periodic only)
// ──────────────────────────────────────────────────────────────────────────────

/**
 * Full sync: fetch remote, merge, push
 * Called periodically every 5 minutes
 */
async function syncNow() {
    if (syncInProgress) {
        console.log('[BG] Sync already in progress, skipping');
        return;
    }

    syncInProgress = true;
    const syncStartTime = Date.now();

    try {
        const token = getToken();
        if (!token) {
            console.log('[BG] No token, skipping sync');
            return;
        }

        console.log('[BG] === SYNC START ===');

        // Fetch remote
        const remoteRes = await fetchGist();
        const local = getDB();
        const remote = remoteRes?.db || null;

        // Merge
        let merged = local;
        if (remote) {
            merged = mergeDBs(local, remote);
            const localCount = Object.keys(local).length;
            const remoteCount = Object.keys(remote).length;
            const mergedCount = Object.keys(merged).length;
            console.log(`[BG] Merge: local=${localCount}, remote=${remoteCount}, merged=${mergedCount}`);
            saveDB(merged);
        } else if (!gistId) {
            console.log('[BG] No remote DB and no gist ID, creating new gist');
            await createGist(local);
            return;
        }

        // Push
        await pushGist(getDB());

        lastSyncTime = Date.now();
        const duration = Date.now() - syncStartTime;
        console.log(`[BG] === SYNC COMPLETE (${duration}ms) ===`);
    } catch (e) {
        if (e.message === 'INVALID_TOKEN') {
            console.error('[BG] Invalid token, user must re-authenticate');
        } else {
            console.error('[BG] Sync error:', e);
        }
    } finally {
        syncInProgress = false;
    }
}

// ──────────────────────────────────────────────────────────────────────────────
// PERIODIC SYNC (5 minutes)
// ──────────────────────────────────────────────────────────────────────────────

function startPeriodicSync() {
    // Initial sync after 10 seconds
    setTimeout(() => {
        syncNow().catch(e => console.error('[BG] Initial sync error:', e));
    }, 10000);

    // Then every 5 minutes (300,000ms)
    periodicSyncTimer = setInterval(() => {
        syncNow().catch(e => console.error('[BG] Periodic sync error:', e));
    }, SYNC_CONFIG.syncIntervalMs);

    console.log('[BG] Periodic sync started (5-minute interval)');
}

// ──────────────────────────────────────────────────────────────────────────────
// MESSAGE ROUTING (content script ↔ background worker)
// ──────────────────────────────────────────────────────────────────────────────

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    (async () => {
        try {
            const { action, payload } = request;
            console.log('[BG] Message:', action);

            switch (action) {
                case 'getDB':
                    sendResponse({ db: getDB() });
                    break;

                case 'saveDB':
                    saveDB(payload.db);
                    console.log('[BG] DB saved (will sync on next 5-min cycle)');
                    sendResponse({ ok: true });
                    break;

                case 'getToken':
                    sendResponse({ token: getToken() });
                    break;

                case 'setToken':
                    saveToken(payload.token);
                    console.log('[BG] Token set, triggering sync');
                    setTimeout(() => syncNow().catch(e => console.error('[BG] Post-token sync error:', e)), 500);
                    sendResponse({ ok: true });
                    break;

                case 'clearToken':
                    clearToken();
                    sendResponse({ ok: true });
                    break;

                case 'syncNow':
                    await syncNow();
                    sendResponse({ ok: true });
                    break;

                case 'getSyncStatus':
                    sendResponse({
                        inProgress: syncInProgress,
                        lastSyncTime,
                        gistId,
                    });
                    break;

                default:
                    sendResponse({ error: 'Unknown action: ' + action });
            }
        } catch (e) {
            console.error('[BG] Message error:', e);
            sendResponse({ error: e.message });
        }
    })();

    // Keep channel open for async response
    return true;
});

// ──────────────────────────────────────────────────────────────────────────────
// INITIALIZATION
// ──────────────────────────────────────────────────────────────────────────────

(async () => {
    // Load gist ID from storage
    const storedGistId = getFromStorage(SYNC_CONFIG.gistIdLsKey);
    if (storedGistId) {
        gistId = storedGistId;
        console.log('[BG] Loaded gist ID:', gistId);
    } else {
        gistId = GIST_CONFIG.defaultId;
        console.log('[BG] Using default gist ID:', gistId);
    }

    // Start periodic sync
    startPeriodicSync();

    console.log('[BG] Service worker initialized');
})();
