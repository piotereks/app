const GIST_CONFIG = {
    owner: 'piotereks',
    filename: 'olx_otomoto_db.json',
    defaultId: 'eb2ae321606877b02d4c75675b8557d4',
};

const SYNC_CONFIG = {
    tokenLsKey: 'gist_token',
    gistIdLsKey: 'gist_id',
    dbKey: 'global_listing_db',
    syncIntervalMs: 300000,
};

let gistId = GIST_CONFIG.defaultId;
let syncInProgress = false;
let periodicSyncTimer = null;
let lastSyncTime = 0;

const DB_NAME = 'olx-ban-db';
const DB_VERSION = 1;
const DB_STORE = 'kv';

function openDB() {
    return new Promise((resolve, reject) => {
        const req = indexedDB.open(DB_NAME, DB_VERSION);
        req.onupgradeneeded = () => {
            const db = req.result;
            if (!db.objectStoreNames.contains(DB_STORE)) {
                db.createObjectStore(DB_STORE);
            }
        };
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => reject(req.error);
    });
}

async function idbGet(key) {
    const db = await openDB();
    return new Promise((resolve, reject) => {
        const tx = db.transaction(DB_STORE, 'readonly');
        const store = tx.objectStore(DB_STORE);
        const req = store.get(key);
        req.onsuccess = () => { resolve(req.result); db.close(); };
        req.onerror = () => { reject(req.error); db.close(); };
    });
}

async function idbSet(key, value) {
    const db = await openDB();
    return new Promise((resolve, reject) => {
        const tx = db.transaction(DB_STORE, 'readwrite');
        const store = tx.objectStore(DB_STORE);
        const req = store.put(value, key);
        req.onsuccess = () => { resolve(); db.close(); };
        req.onerror = () => { reject(req.error); db.close(); };
    });
}

async function idbRemove(key) {
    const db = await openDB();
    return new Promise((resolve, reject) => {
        const tx = db.transaction(DB_STORE, 'readwrite');
        const store = tx.objectStore(DB_STORE);
        const req = store.delete(key);
        req.onsuccess = () => { resolve(); db.close(); };
        req.onerror = () => { reject(req.error); db.close(); };
    });
}

async function getToken() {
    const val = await idbGet(SYNC_CONFIG.tokenLsKey);
    return val || '';
}

async function saveToken(token) {
    const trimmed = token.trim();
    await idbSet(SYNC_CONFIG.tokenLsKey, trimmed);
    console.log('[BG] Token saved (length: ' + trimmed.length + ')');
}

async function clearToken() {
    await idbRemove(SYNC_CONFIG.tokenLsKey);
    console.log('[BG] Token cleared');
}

async function getDB() {
    const stored = await idbGet(SYNC_CONFIG.dbKey);
    if (!stored) return {};
    return stored;
}

async function saveDB(db) {
    await idbSet(SYNC_CONFIG.dbKey, db);
}

function now() {
    return new Date().toISOString();
}

function mergeDBs(local, remote) {
    const merged = Object.assign({}, local);

    for (const [k, rv] of Object.entries(remote)) {
        const lv = local[k];
        if (!lv) {
            merged[k] = rv;
            continue;
        }

        const entry = Object.assign({}, lv);

        const lBan = lv.bannedAt || '';
        const rBan = rv.bannedAt || '';
        if (rBan > lBan) {
            entry.banned = rv.banned;
            entry.bannedAt = rv.bannedAt;
            if (rv.status !== undefined) entry.status = rv.status;
        }

        const lRat = lv.ratedAt || '';
        const rRat = rv.ratedAt || '';
        if (rRat > lRat) {
            entry.rating = rv.rating;
            entry.ratedAt = rv.ratedAt;
        }

        if (rv.comment !== undefined && (rv.updatedAt || '') >= (lv.updatedAt || '')) {
            entry.comment = rv.comment;
        }

        const lVie = lv.viewedAt || '';
        const rVie = rv.viewedAt || '';
        if (rVie > lVie) entry.viewedAt = rv.viewedAt;

        if (!entry.id && rv.id) entry.id = rv.id;
        if (!entry.site && rv.site) entry.site = rv.site;

        const lUpd = lv.updatedAt || '';
        const rUpd = rv.updatedAt || '';
        if (rUpd > lUpd) entry.updatedAt = rv.updatedAt;

        merged[k] = entry;
    }

    return merged;
}

async function createGist(db) {
    const token = await getToken();
    if (!token) throw new Error('NO_TOKEN');

    const body = {
        description: 'OLX/Otomoto listing DB (synced by WebExtension)',
        public: false,
        files: {
            [GIST_CONFIG.filename]: {
                content: JSON.stringify(db, null, 2),
            },
        },
    };

    const res = await fetch('https://api.github.com/gists', {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json',
            'Accept': 'application/vnd.github+json',
        },
        body: JSON.stringify(body),
    });

    if (!res.ok) {
        const txt = await res.text().catch(() => '<no body>');
        throw new Error(`Gist create failed: ${res.status} ${txt}`);
    }

    const data = await res.json();
    gistId = data.id;
    await idbSet(SYNC_CONFIG.gistIdLsKey, gistId);
    console.log('[BG] Created new gist. ID:', gistId);
    return data;
}

async function fetchGist() {
    if (!gistId) {
        console.warn('[BG] No Gist ID, skipping fetch');
        return null;
    }

    const token = await getToken();
    if (!token) {
        console.warn('[BG] No token, cannot fetch gist');
        return null;
    }

    const res = await fetch(`https://api.github.com/gists/${gistId}`, {
        headers: {
            'Authorization': `Bearer ${token}`,
            'Accept': 'application/vnd.github+json',
        },
    });

    if (res.status === 401) {
        console.error('[BG] Gist fetch 401 — invalid token');
        await clearToken();
        throw new Error('INVALID_TOKEN');
    }

    if (!res.ok) {
        const txt = await res.text().catch(() => '<no body>');
        console.warn('[BG] Gist fetch failed:', res.status, txt);
        return null;
    }

    const data = await res.json();
    const file = data.files?.[GIST_CONFIG.filename];
    if (!file || !file.content) {
        console.warn('[BG] Gist file not found');
        return null;
    }

    let parsed = null;
    try {
        parsed = JSON.parse(file.content);
    } catch (e) {
        console.warn('[BG] Failed to parse gist content:', e);
        return null;
    }

    return { db: parsed, gist: data };
}

async function pushGist(db) {
    const token = await getToken();
    if (!token) throw new Error('NO_TOKEN');

    const content = JSON.stringify(db, null, 2);

    if (!gistId) {
        console.log('[BG] No gist ID, creating new gist');
        await createGist(db);
        return;
    }

    const body = {
        files: {
            [GIST_CONFIG.filename]: { content },
        },
    };

    const res = await fetch(`https://api.github.com/gists/${gistId}`, {
        method: 'PATCH',
        headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json',
            'Accept': 'application/vnd.github+json',
        },
        body: JSON.stringify(body),
    });

    if (res.status === 401) {
        console.error('[BG] Gist push 401 — invalid token');
        await clearToken();
        throw new Error('INVALID_TOKEN');
    }

    if (!res.ok) {
        const txt = await res.text().catch(() => '<no body>');
        console.warn('[BG] Gist push failed:', res.status, txt);
    } else {
        console.log('[BG] Gist push successful');
    }
}

async function syncNow() {
    if (syncInProgress) {
        console.log('[BG] Sync already in progress, skipping');
        return;
    }

    syncInProgress = true;
    const syncStartTime = Date.now();

    try {
        const token = await getToken();
        if (!token) {
            console.log('[BG] No token, skipping sync');
            return;
        }

        console.log('[BG] === SYNC START ===');

        const remoteRes = await fetchGist();
        const local = await getDB();
        const remote = remoteRes?.db || null;

        let merged = local;
        if (remote) {
            merged = mergeDBs(local, remote);
            const localCount = Object.keys(local).length;
            const remoteCount = Object.keys(remote).length;
            const mergedCount = Object.keys(merged).length;
            console.log(`[BG] Merge: local=${localCount}, remote=${remoteCount}, merged=${mergedCount}`);
            await saveDB(merged);
        } else if (!gistId) {
            console.log('[BG] No remote DB and no gist ID, creating new gist');
            await createGist(local);
            return;
        }

        await pushGist(await getDB());

        lastSyncTime = Date.now();
        const duration = Date.now() - syncStartTime;
        console.log(`[BG] === SYNC COMPLETE (${duration}ms) ===`);
    } catch (e) {
        if (e.message === 'INVALID_TOKEN') {
            console.error('[BG] Invalid token, user must re-authenticate');
        } else {
            console.error('[BG] Sync error:', e);
        }
    } finally {
        syncInProgress = false;
    }
}

function startPeriodicSync() {
    setTimeout(() => {
        syncNow().catch(e => console.error('[BG] Initial sync error:', e));
    }, 10000);

    periodicSyncTimer = setInterval(() => {
        syncNow().catch(e => console.error('[BG] Periodic sync error:', e));
    }, SYNC_CONFIG.syncIntervalMs);

    console.log('[BG] Periodic sync started (5-minute interval)');
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    (async () => {
        try {
            const { action, payload } = request;
            console.log('[BG] Message:', action);

            switch (action) {
                case 'getDB':
                    sendResponse({ db: await getDB() });
                    break;

                case 'saveDB':
                    await saveDB(payload.db);
                    console.log('[BG] DB saved (will sync on next 5-min cycle)');
                    sendResponse({ ok: true });
                    break;

                case 'getToken':
                    sendResponse({ token: await getToken() });
                    break;

                case 'setToken':
                    await saveToken(payload.token);
                    console.log('[BG] Token set, triggering sync');
                    setTimeout(() => syncNow().catch(e => console.error('[BG] Post-token sync error:', e)), 500);
                    sendResponse({ ok: true });
                    break;

                case 'clearToken':
                    await clearToken();
                    sendResponse({ ok: true });
                    break;

                case 'syncNow':
                    await syncNow();
                    sendResponse({ ok: true });
                    break;

                case 'getSyncStatus':
                    sendResponse({
                        inProgress: syncInProgress,
                        lastSyncTime,
                        gistId,
                    });
                    break;

                default:
                    sendResponse({ error: 'Unknown action: ' + action });
            }
        } catch (e) {
            console.error('[BG] Message error:', e);
            sendResponse({ error: e.message });
        }
    })();

    return true;
});

(async () => {
    const storedGistId = await idbGet(SYNC_CONFIG.gistIdLsKey);
    if (storedGistId) {
        gistId = storedGistId;
        console.log('[BG] Loaded gist ID:', gistId);
    } else {
        gistId = GIST_CONFIG.defaultId;
        console.log('[BG] Using default gist ID:', gistId);
    }

    startPeriodicSync();

    console.log('[BG] Service worker initialized');
})();
