// ── Otomoto Site Module ──────────────────────────────────────────────────────
// Sets Otomoto-specific config on __BAN, then inits shared engine.
// Runs only on https://*.otomoto.pl/* (see manifest.json).
// ──────────────────────────────────────────────────────────────────────────────

(function() {

console.log('[OLX Ban] Otomoto site module loaded');

window.__BAN = window.__BAN || {};

__BAN.SITE         = 'otomoto';
__BAN.CHIP_POS     = 'left';
__BAN.SEARCH_ORDER = 'created_at_first:desc';
__BAN.TITLE_SEL    = 'h2 > a';
__BAN.PRICE_SEL    = 'h6, h3, h4, [class*="title"] a, a[class*="title"], [data-testid*="title"] a, a[data-testid*="title"]';

__BAN.HEART_SEL = [
    '[data-testid*="favourite"]',
    '[data-testid*="observed"]',
    '[data-testid*="wishlist"]',
    '[aria-label*="ulub"]',
    '[aria-label*="obserw"]',
    '[aria-label*="watch"]',
    '[data-cy*="favourite"]',
    '[data-cy*="favorite"]',
    'button[class*="Favourite"]',
    'button[class*="Observed"]',
    'button[class*="favourite"]',
    'button[class*="favorite"]',
].join(',');

__BAN.CARD_SELS = [
    '[data-testid="listing-ad"]',
    '[data-testid="ad-card"]',
    '[data-testid*="listing"]',
    '[data-testid*="AdCard"]',
    '[class*="listing"]',
    '[class*="offer-item"]',
    '[class*="offer-card"]',
    '[class*="ad-card"]',
    '[class*="offer"]',
    '[class*="card"]',
    'article[data-id]',
    'article',
    'section',
    'li',
];

__BAN.init();

})();