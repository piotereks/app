// ── Otomoto Site Module ──────────────────────────────────────────────────────
// Sets Otomoto-specific config on __BAN, then inits shared engine.
// Runs only on https://*.otomoto.pl/* (see manifest.json).
// ──────────────────────────────────────────────────────────────────────────────

(function() {

console.log('[OLX Ban] Otomoto site module loaded');

window.__BAN = window.__BAN || {};

__BAN.SITE         = 'otomoto';
__BAN.CHIP_POS     = 'left';
__BAN.SEARCH_ORDER = 'created_at_first:desc';
__BAN.TITLE_SEL    = 'h2 > a';
__BAN.PRICE_SEL    = 'h6, h3, h4, [class*="title"] a, a[class*="title"], [data-testid*="title"] a, a[data-testid*="title"]';

__BAN.HEART_SEL = [
    '[data-testid*="favourite"]',
    '[data-testid*="observed"]',
    '[data-testid*="wishlist"]',
    '[aria-label*="ulub"]',
    '[aria-label*="obserw"]',
    '[aria-label*="watch"]',
    '[data-cy*="favourite"]',
    '[data-cy*="favorite"]',
    'button[class*="Favourite"]',
    'button[class*="Observed"]',
    'button[class*="favourite"]',
    'button[class*="favorite"]',
].join(',');

__BAN.CARD_SELS = [
    '[data-testid="listing-ad"]',
    '[data-testid="ad-card"]',
    '[data-testid*="listing"]',
    '[data-testid*="AdCard"]',
    '[class*="listing"]',
    '[class*="offer-item"]',
    '[class*="offer-card"]',
    '[class*="ad-card"]',
    '[class*="offer"]',
    '[class*="card"]',
    'article[data-id]',
    'article',
    'section',
    'li',
];

__BAN.OBSERVER_SELS = [
    'article',
    'section',
    'li',
    '[class*="offer-item"]',
    '[class*="offer-card"]',
    '[class*="offer"]',
    '[class*="listing"]',
];

__BAN.LISTING_PATTERNS = [
    '/ogloszenie/',
    '/advert/',
    'otomoto.pl',
    'otomoto',
    '/osobowe/',
];

function buildInlineControls(id, data, dbKey) {
    var controls = document.createElement('div');
    controls.className = 'otomoto-inline-controls';
    controls.setAttribute('data-db-key', dbKey);
    controls.setAttribute('data-id', id);
    controls.style.cssText = [
        'display:flex',
        'align-items:center',
        'gap:6px',
        'padding:6px 12px',
        'margin:0 0 6px auto',
        'background:rgba(0,0,0,0.85)',
        'border-radius:6px',
        'box-sizing:border-box',
        'width:fit-content',
        'position:relative',
        'z-index:9999',
    ].join(';');

    var H = __BAN.helpers;

    if (data.viewedAt) {
        var eye = document.createElement('span');
        eye.className = 'otomoto-inline-eye';
        eye.textContent = '\uD83D\uDC41';
        eye.style.cssText = 'font-size:14px;line-height:1;opacity:0.9;pointer-events:none;';
        controls.appendChild(eye);
    }

    var r = H.getRatingStyle(data.rating);
    var star = document.createElement('span');
    star.className = 'otomoto-inline-star';
    star.textContent = r.label;
    star.style.cssText = [
        'font-size:18px',
        'color:' + r.color,
        'line-height:1',
        'cursor:pointer',
        'user-select:none',
    ].join(';');
    star.addEventListener('click', function(e) {
        e.preventDefault();
        e.stopPropagation();
        H.setRatingByKey(id, dbKey);
    });
    controls.appendChild(star);

    var comment = document.createElement('span');
    comment.className = 'otomoto-inline-comment';
    comment.textContent = data.comment || 'comment';
    comment.title = data.comment || '';
    comment.style.cssText = [
        'font-size:11px',
        'font-weight:' + (data.comment ? 'bold' : 'normal'),
        'color:#ffd700',
        'background:rgba(0,0,0,0.35)',
        'border:1px solid rgba(255,215,0,0.35)',
        'border-radius:999px',
        'padding:' + (data.comment ? '2px 8px' : '0'),
        'max-width:100px',
        'white-space:nowrap',
        'overflow:hidden',
        'text-overflow:ellipsis',
        'line-height:1.4',
        'cursor:pointer',
    ].join(';');
    comment.addEventListener('click', function(e) {
        e.stopPropagation();
        var inp = controls.querySelector('.otomoto-inline-comment-input');
        if (inp) {
            inp.focus();
            inp.select();
        }
    });
    controls.appendChild(comment);

    var input = document.createElement('input');
    input.className = 'otomoto-inline-comment-input';
    input.type = 'text';
    input.setAttribute('autocomplete', 'off');
    input.maxLength = 50;
    input.placeholder = '';
    input.value = data.comment || '';
    input.style.cssText = [
        'width:100px',
        'padding:4px 6px',
        'border-radius:4px',
        'border:1px solid rgba(255,255,255,0.25)',
        'background:rgba(255,255,255,0.12)',
        'color:white',
        'font-size:11px',
        'outline:none',
        'box-sizing:border-box',
    ].join(';');
    input.addEventListener('blur', function() {
        var val = H.normalizeComment(input.value);
        comment.textContent = val || 'comment';
        comment.style.fontWeight = val ? 'bold' : 'normal';
        comment.style.padding = val ? '2px 8px' : '0';
        H.updateVisibleComment(dbKey, val);
    });
    input.addEventListener('input', function(e) {
        var val = H.normalizeComment(e.target.value);
        e.target.value = val;
        H.setCommentByKey(id, dbKey, val);
    });
    controls.appendChild(input);

    var btn = document.createElement('button');
    btn.className = 'otomoto-inline-btn';
    btn.textContent = data.banned ? 'BANNED' : 'BAN';
    btn.style.cssText = [
        'background:' + (data.banned ? '#cc0000' : '#222'),
        'color:white',
        'border:none',
        'font-size:11px',
        'font-weight:bold',
        'padding:4px 10px',
        'border-radius:4px',
        'cursor:pointer',
        'line-height:1.4',
    ].join(';');
    btn.addEventListener('click', function(e) {
        e.preventDefault();
        e.stopPropagation();
        if (data.banned) {
            H.unbanByKey(id, dbKey);
        } else {
            H.banByKey(id, dbKey);
        }
    });
    controls.appendChild(btn);

    return controls;
}

__BAN.renderInlineControls = function(db) {
    var pageId = __BAN.helpers.extractId(location.href);
    var H = __BAN.helpers;

    document.querySelectorAll('.otomoto-inline-controls').forEach(function(el) { el.remove(); });

    var seenKeys = {};

    document.querySelectorAll('a[href]').forEach(function(a) {
        var href = (a.getAttribute('href') || '').toLowerCase();
        if (!href || href.startsWith('#') || href.startsWith('javascript:') || href.startsWith('mailto:')) return;

        var id = H.extractId(a.href);
        if (!id || id === pageId) return;
        if (!H.isListingLink(a)) return;
        if (a.closest('header') || a.closest('nav') || a.closest('[role="dialog"]')) return;

        var card = H.getCard(a);
        if (!card) return;

        var dbKey = 'otomoto:' + id;
        if (seenKeys[dbKey]) return;
        seenKeys[dbKey] = true;

        var collapseBar = document.querySelector('.olx-ban-collapse-bar[data-db-key="' + dbKey + '"]');
        if (collapseBar) {
            var toggle = collapseBar.querySelector('.olx-ban-collapse-toggle');
            if (!toggle || toggle.textContent !== 'Collapse') return;
        }

        var data = (db && db[dbKey]) || {};
        var controls = buildInlineControls(id, data, dbKey);
        card.after(controls);
    });
};

__BAN.updateInlineControls = function(dbKey, data) {
    var controls = document.querySelector('.otomoto-inline-controls[data-db-key="' + dbKey + '"]');
    if (!controls) return;
    var H = __BAN.helpers;

    var star = controls.querySelector('.otomoto-inline-star');
    if (star) {
        var r = H.getRatingStyle(data.rating);
        star.textContent = r.label;
        star.style.color = r.color;
    }

    var comment = controls.querySelector('.otomoto-inline-comment');
    if (comment) {
        comment.textContent = data.comment || 'comment';
        comment.title = data.comment || '';
        comment.style.fontWeight = data.comment ? 'bold' : 'normal';
        comment.style.padding = data.comment ? '2px 8px' : '0';
    }

    var input = controls.querySelector('.otomoto-inline-comment-input');
    if (input && document.activeElement !== input) {
        input.value = data.comment || '';
    }

    var btn = controls.querySelector('.otomoto-inline-btn');
    if (btn) {
        btn.textContent = data.banned ? 'BANNED' : 'BAN';
        btn.style.background = data.banned ? '#cc0000' : '#222';
    }
};

__BAN.init();

})();