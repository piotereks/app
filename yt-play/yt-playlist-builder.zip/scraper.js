// scraper.js
// Injected via browser.scripting.executeScript({ files: ['scraper.js'] }).
// This is a real, packaged extension file — NOT a function body serialized
// and sent at runtime. Read-only: no DOM writes anywhere in this file.
// Reads its options from browser.storage.local (already saved by ui.js)
// and returns a result object as its completion value.

function parseTimeToSeconds(text) {
  if (!text) return null;
  const parts = text.trim().split(':').map(Number);
  if (parts.some(isNaN)) return null;
  let s = 0;
  if (parts.length === 3) s = parts[0] * 3600 + parts[1] * 60 + parts[2];
  else if (parts.length === 2) s = parts[0] * 60 + parts[1];
  else s = parts[0];
  return s;
}

function parseAriaLabelDuration(label) {
  if (!label) return null;
  const h = /(\d+)\s*hour/.exec(label);
  const m = /(\d+)\s*minute/.exec(label);
  const s = /(\d+)\s*second/.exec(label);
  if (!h && !m && !s) return null;
  return (h ? +h[1] * 3600 : 0) + (m ? +m[1] * 60 : 0) + (s ? +s[1] : 0);
}

function readDurationSeconds(item) {
  // READ ONLY — no writes to the element or the DOM anywhere in this function.
  const badge = item.querySelector('ytd-thumbnail-overlay-time-status-renderer');
  if (!badge) return { seconds: null, text: null };

  const shapeText = badge.querySelector('.ytBadgeShapeText');
  if (shapeText && shapeText.textContent.trim()) {
    const sec = parseTimeToSeconds(shapeText.textContent);
    if (sec !== null) return { seconds: sec, text: shapeText.textContent.trim() };
  }

  const badgeShape = badge.querySelector('badge-shape[aria-label]');
  if (badgeShape) {
    const sec = parseAriaLabelDuration(badgeShape.getAttribute('aria-label'));
    if (sec !== null) return { seconds: sec, text: badgeShape.getAttribute('aria-label') };
  }

  const oldText = badge.querySelector('#text');
  if (oldText && oldText.textContent.trim()) {
    const sec = parseTimeToSeconds(oldText.textContent);
    if (sec !== null) return { seconds: sec, text: oldText.textContent.trim() };
  }

  return { seconds: null, text: null };
}

function readIsWatched(item) {
  // READ ONLY.
  const resumeBar = item.querySelector('ytd-thumbnail-overlay-resume-playback-renderer');
  if (!resumeBar) return false;
  const progressEl = resumeBar.querySelector('#progress, .ytThumbnailOverlayProgressBarHost');
  if (!progressEl) return !!resumeBar.textContent.trim();
  const style = progressEl.getAttribute('style') || '';
  const widthMatch = /width:\s*([\d.]+)%/.exec(style);
  return widthMatch ? parseFloat(widthMatch[1]) > 0 : true;
}

function isShortsItem(item) {
  const tag = item.tagName.toLowerCase();
  const href = item.querySelector('#video-title, a')?.getAttribute('href') || '';
  
  if (tag.includes('reel') || tag.includes('shorts')) return true;
  if (tag === 'ytm-shorts-lockup-view-model' || tag === 'ytm-shorts-lockup-view-model-v2') return true;
  if (href.includes('/shorts/')) return true;
  
  const badge = item.querySelector('ytd-thumbnail-overlay-time-status-renderer');
  if (!badge) return true;
  
  return false;
}

function removeShortsFromDOM() {
  let removed = 0;
  
  const selectors = [
    'ytd-video-renderer',
    'ytd-reel-video-renderer',
    'ytd-grid-video-renderer',
    'ytm-shorts-lockup-view-model',
    'ytm-shorts-lockup-view-model-v2'
  ];
  
  selectors.forEach(selector => {
    document.querySelectorAll(selector).forEach(item => {
      if (isShortsItem(item)) {
        item.remove();
        removed++;
      }
    });
  });
  
  return removed;
}

async function scrapeAndReturn() {
  // Content scripts have direct access to browser.storage - no messaging needed.
  const stored = await browser.storage.local.get(['minTime', 'maxTime', 'filterWatched', 'filterShorts']);
  const minDurationSeconds = parseTimeToSeconds(stored.minTime || '');
  const maxDurationSeconds = parseTimeToSeconds(stored.maxTime || '');
  const excludeWatched = !!stored.filterWatched;
  const excludeShorts = !!stored.filterShorts;

  // Remove shorts from DOM if enabled (including future ones via MutationObserver)
  let shortsRemoved = 0;
  if (excludeShorts) {
    shortsRemoved = removeShortsFromDOM();

    const observer = new MutationObserver((mutations) => {
      for (const mutation of mutations) {
        for (const node of mutation.addedNodes) {
          if (node.nodeType === Node.ELEMENT_NODE) {
            if (node.matches('ytd-video-renderer') && isShortsItem(node)) {
              node.remove();
              shortsRemoved++;
            } else {
              const shortsInSubtree = node.querySelectorAll('ytd-video-renderer');
              shortsInSubtree.forEach(item => {
                if (isShortsItem(item)) {
                  item.remove();
                  shortsRemoved++;
                }
              });
            }
          }
        }
      }
    });

    observer.observe(document.body, { childList: true, subtree: true });
    // Give a moment for observer to catch any immediate additions
    await new Promise(r => setTimeout(r, 100));
    observer.disconnect();
  }

  // READ ONLY DOM SCAN — document.querySelectorAll, no mutation methods used anywhere below.
  const items = Array.from(document.querySelectorAll('ytd-video-renderer'));
  const results = [];
  const stats = { total: items.length, noVideoId: 0, noDuration: 0, tooShort: 0, tooLong: 0, watched: 0, kept: 0, shortsRemoved };

  for (const item of items) {
    const titleEl = item.querySelector('#video-title');
    const channelEl = item.querySelector('#channel-info #text, ytd-channel-name #text');
    if (!titleEl) { stats.noVideoId++; continue; }

    const href = titleEl.getAttribute('href') || '';
    const match = href.match(/[?&]v=([a-zA-Z0-9_-]{11})/);
    if (!match) { stats.noVideoId++; continue; }

    const videoId = match[1];
    const title = titleEl.getAttribute('title') || titleEl.textContent.trim();
    const channel = channelEl ? channelEl.textContent.trim() : '';

    if (excludeWatched && readIsWatched(item)) { stats.watched++; continue; }

    const d = readDurationSeconds(item);
    if (d.seconds === null) { stats.noDuration++; continue; }
    if (minDurationSeconds !== null && d.seconds < minDurationSeconds) { stats.tooShort++; continue; }
    if (maxDurationSeconds !== null && d.seconds > maxDurationSeconds) { stats.tooLong++; continue; }

    stats.kept++;
    results.push({ videoId, title, channel, duration: d.text, durationSeconds: d.seconds });
  }

  const seen = new Set();
  const deduped = results.filter(r => (seen.has(r.videoId) ? false : seen.add(r.videoId)));

  const params = new URLSearchParams(window.location.search);
  const searchPhrase = params.get('search_query') || 'search';

  return { items: deduped, stats, searchPhrase };
}

// Completion value of this script = the resolved value of this call.
// browser.scripting.executeScript awaits a returned Promise automatically
// and uses its resolved value as the injection result.
scrapeAndReturn();
