git fetch --// background.js - Service worker for YT Playlist Builder
// Minimal: the heavy lifting is done by scraper.js content script

chrome.runtime.onInstalled.addListener(() => {
  console.log('[background.js] YT Playlist Builder installed');
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'executeScraper') {
    console.log('[background.js] executeScraper called for tab:', message.tabId);
    chrome.scripting.executeScript({
      target: { tabId: message.tabId },
      files: ['scraper.js']
    }).then((execResults) => {
      console.log('[background.js] executeScript result:', execResults);
      sendResponse({ success: true, result: execResults });
    }).catch((err) => {
      console.log('[background.js] executeScript error:', err);
      sendResponse({ success: false, error: err.message });
    });
    return true; // Keep message channel open for async response
  }
});
