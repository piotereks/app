function $(id) { return document.getElementById(id); }

function parseTimeToSeconds(text) {
  if (!text) return null;
  const parts = text.trim().split(':').map(Number);
  if (parts.some(isNaN)) return null;
  let s = 0;
  if (parts.length === 3) s = parts[0] * 3600 + parts[1] * 60 + parts[2];
  else if (parts.length === 2) s = parts[0] * 60 + parts[1];
  else s = parts[0];
  return s;
}

function makePlaylistTitle(searchPhrase) {
  const phrase = (searchPhrase || 'search').trim().replace(/\s+/g, '_').replace(/[^\w\-]/g, '') || 'search';
  const now = new Date();
  const pad = n => String(n).padStart(2, '0');
  const yyyymmdd = `${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(now.getDate())}`;
  const hhmm = `${pad(now.getHours())}${pad(now.getMinutes())}`;
  return `tmp_${phrase}_${yyyymmdd}_${hhmm}`;
}

// Popup: query the last focused normal window's active tab.
async function getTargetTab() {
  const tabs = await browser.tabs.query({ active: true, windowType: 'normal' });
  const tab = tabs[0];
  if (!tab) return { win: null, tab: null };
  const win = await browser.windows.get(tab.windowId);
  return { win, tab };
}

function setStatus(msg, isError) {
  const el = $('status');
  el.textContent = msg;
  el.className = 'status ' + (isError ? 'error' : 'ok');
}

async function loadSettings() {
  const stored = await browser.storage.local.get(['criteria', 'minTime', 'maxTime', 'filterWatched', 'filterShorts']);
  if (typeof stored.criteria === 'string') $('criteria').value = stored.criteria;
  if (typeof stored.minTime === 'string') $('minTime').value = stored.minTime;
  if (typeof stored.maxTime === 'string') $('maxTime').value = stored.maxTime;
  if (typeof stored.filterWatched === 'boolean') $('filterWatched').checked = stored.filterWatched;
  if (typeof stored.filterShorts === 'boolean') $('filterShorts').checked = stored.filterShorts;
}

async function handleSearch() {
  const criteria = $('criteria').value.trim();
  const filterWatched = $('filterWatched').checked;
  const filterShorts = $('filterShorts').checked;

  if (!criteria) {
    setStatus('Enter search criteria first.', true);
    return;
  }

  await browser.storage.local.set({ criteria, filterWatched, filterShorts });

  const targetUrl = 'https://www.youtube.com/results?search_query=' + encodeURIComponent(criteria);
  const { win, tab } = await getTargetTab();
  
  if (win && tab && tab.url && tab.url.includes('youtube.com')) {
    await browser.tabs.update(tab.id, { url: targetUrl });
    setStatus('Updated YouTube tab with search results. Scroll down to load more entries, then click "Create Playlist".');
  } else {
    await browser.tabs.create({ url: targetUrl });
    setStatus('Opened search results in new tab. Scroll down to load more entries, then click "Create Playlist".');
  }
}

async function handleCreate() {
  const criteria = $('criteria').value.trim();
  const minTimeText = $('minTime').value.trim();
  const maxTimeText = $('maxTime').value.trim();
  const filterWatched = $('filterWatched').checked;
  const filterShorts = $('filterShorts').checked;

  await browser.storage.local.set({ criteria, minTime: minTimeText, maxTime: maxTimeText, filterWatched, filterShorts });

  const minDurationSeconds = parseTimeToSeconds(minTimeText);
  const maxDurationSeconds = parseTimeToSeconds(maxTimeText);

  if (minTimeText && minDurationSeconds === null) {
    setStatus('Min time format invalid. Use mm:ss (e.g. 1:00).', true);
    return;
  }
  if (maxTimeText && maxDurationSeconds === null) {
    setStatus('Max time format invalid. Use mm:ss (e.g. 7:59).', true);
    return;
  }

  const { win, tab } = await getTargetTab();
  if (!win || !tab || !tab.url) {
    setStatus('No browser window with an active tab found.', true);
    return;
  }

  const onYouTube = tab.url.includes('youtube.com');

  if (criteria) {
    const targetUrl = 'https://www.youtube.com/results?search_query=' + encodeURIComponent(criteria);
    let currentMatches = false;
    if (onYouTube) {
      try {
        const u = new URL(tab.url);
        currentMatches = u.pathname === '/results' && u.searchParams.get('search_query') === criteria;
      } catch (e) {
        currentMatches = false;
      }
    }

    if (!currentMatches) {
      await browser.tabs.update(tab.id, { url: targetUrl });
      setStatus('Opened search results in your browser window. Scroll down there to load more entries, then click "Create playlist" again.');
      return;
    }
  } else if (!onYouTube) {
    setStatus('Open a YouTube page in your browser window first, or type search criteria above.', true);
    return;
  }

  setStatus('Scraping current page...');

  let execResults;
  try {
    execResults = await browser.scripting.executeScript({
      target: { tabId: tab.id },
      files: ['scraper.js']
    });
  } catch (err) {
    setStatus('Script injection failed: ' + err.message + '. Reload the YouTube tab and try again.', true);
    return;
  }

  const payload = execResults && execResults[0] && execResults[0].result;
  if (!payload) {
    setStatus('No result from page. Try again.', true);
    return;
  }

  const { items, stats, searchPhrase } = payload;

  if (items.length === 0) {
    setStatus(
      `No matching videos (checked ${stats.total} on page: ${stats.watched} watched, ${stats.tooShort} too short, ${stats.tooLong} too long, ${stats.noDuration} unknown length). Scroll for more or loosen filters.`,
      true
    );
    return;
  }

  const limited = items.slice(0, 50);
  const url = 'https://www.youtube.com/watch_videos?video_ids=' + limited.map(i => i.videoId).join(',');
  const title = makePlaylistTitle(searchPhrase);

  await browser.tabs.create({ url, windowId: win.id });
  setStatus(`Playlist opened: ${limited.length} of ${items.length} matching videos. Suggested name: ${title}`);
}

document.addEventListener('DOMContentLoaded', () => {
  loadSettings();
  $('searchBtn').addEventListener('click', handleSearch);
  $('createBtn').addEventListener('click', handleCreate);
  $('criteria').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') handleSearch();
  });
});
